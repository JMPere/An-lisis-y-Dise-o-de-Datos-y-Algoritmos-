<?php
session_start();
include_once ("gestionBD.php");
include_once ("gestionarProyectos.php");

$oid_pro = $_SESSION["OID_PROYECTO"];
$conexion = crearConexionBD();
$vista = consultarUnProyecto($conexion, $oid_pro);
$conexion = cerrarConexionBD($conexion);

if (isset($_SESSION["modificar"])) {
	$modificar = TRUE;
	unset($_SESSION["modificar"]);
}
?>



<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Mi Proyecto</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type="text/css" media="screen" href="css/navbar2.css">
        <link rel="stylesheet" type="text/css" media="screen" href="css/main.css">
        <link rel="stylesheet" type="text/css" media="screen" href="css/main.css">
        <script src="main.js"></script>
        <?php if (isset($modificar)) { ?>
			<style>
				label:hover,
				label:hover ~
				label {
					color: orange;
				}

			</style>
		<?php } ?> 
        
        
    </head>
<?php
include_once 'cabecera.php';
?>


    <body>
        <h1>Mis Proyectos</h1>
        <div class="contenedor">
            <div class="izq"> <!--Parte izq pagina con titulo, descripcion, boton y valoracion-->
                <div id="mifuente">
                    <p1><?php echo $vista["NOMBRE"]; ?></p1><br>
                    
                    <?php if(!isset($modificar)){ ?> <!--  -->
                    
                    <div class="descr" style="margin-top: 3.5%" style="margin-bottom: 3%""><?php echo $vista["DESCRIPCION"]; ?></div>
                    
                    <form style="margin-top: 21.5%">
                        <p2>Valoración:</p2>
                     
                        <p class="clasificacion"> <!--Estrellas-->
                            <input id="radio1" type="radio" name="estrellas" value="5" disabled  <?php if ($vista["VALORACION"] == 5) { echo "checked";}?> ><!--
                                --><label for="radio1">★</label><!--
                                --><input  id="radio2" type="radio" name="estrellas" value="4" disabled  <?php if ($vista["VALORACION"] == 4) { echo "checked";}?>><!--
                                --><label for="radio2">★</label><!--
                                --><input  id="radio3" type="radio" name="estrellas" value="3" disabled  <?php if ($vista["VALORACION"] == 3) { echo "checked";}?>><!--
                                --><label for="radio3">★</label><!--
                                --><input  id="radio4" type="radio" name="estrellas" value="2" disabled  <?php if ($vista["VALORACION"] == 2) { echo "checked";}?>><!--
                                --><label for="radio4">★</label><!--
                                --><input  id="radio5" type="radio" name="estrellas" value="1" disabled  <?php if ($vista["VALORACION"] == 1) { echo "checked";}?>><!--
                                --><label for="radio5">★</label>
                        </p>
					</form>
                    
                    <form action="accion_modificar_descripcion.php" method="post">	<input class="botonModificar" type="submit" value="Modificar"></form>
                    
                	<?php }else{ ?>
                	
                	
                	
                	<form action="accion_alta_valoracion.php" method="post">                   
                     <textarea class="comentarioMueble" name="DescripcionModificada"><?php echo $vista["DESCRIPCION"]?></textarea>
                     
                     	<p2>Valoración:</p2>
                        <p class="clasificacion"> <!--Estrellas-->
                            <input id="radio1" type="radio" name="estrellas" value="5"  <?php if ($vista["VALORACION"] == 5) { echo "checked";}?> ><!--
                                --><label for="radio1">★</label><!--
                                --><input  id="radio2" type="radio" name="estrellas" value="4"  <?php if ($vista["VALORACION"] == 4) { echo "checked";}?>><!--
                                --><label for="radio2">★</label><!--
                                --><input  id="radio3" type="radio" name="estrellas" value="3"  <?php if ($vista["VALORACION"] == 3) { echo "checked";}?>><!--
                                --><label for="radio3">★</label><!--
                                --><input  id="radio4" type="radio" name="estrellas" value="2"  <?php if ($vista["VALORACION"] == 2) { echo "checked";}?>><!--
                                --><label for="radio4">★</label><!--
                                --><input  id="radio5" type="radio" name="estrellas" value="1"  <?php if ($vista["VALORACION"] == 1) { echo "checked";}?>><!--
                                --><label for="radio5">★</label>
                        </p>
                        <input class="botonModificar" type="submit" value="Guardar">
					</form>
					<form action="ProyectoIndv.php" method="post"><input class="botonModificar" type="submit" value="Cancelar"></form>
					
					
                	
                	<?php } ?>
                	
                     
                    	
                    
                </div>
            </div>

            <div class="item">
                <p3>imagenes</p3>
                <a href="ProyectoIndv.html"><img class="plus" src="images/plus.png" style="width: 3%;"></a><br>
                <div class="fondoImagenes">
                    
                    <img class="foto" src="images/silla.png" >
                    <img class="foto" src="images/silla2.jpg">
                    <img class="foto" src="images/silla.png" >
                    <img class="foto" src="images/silla2.jpg">
                    <img class="foto" src="images/silla2.jpg">
                    <img class="foto" src="images/silla2.jpg">
                    <img class="foto" src="images/silla.png" >
                    <img class="foto" src="images/silla2.jpg">
                    <img class="foto" src="images/silla.png" >
                    <img class="foto" src="images/silla2.jpg">
                    <img class="foto" src="images/silla2.jpg">
                    <img class="foto" src="images/silla2.jpg">    
                </div>
            </div>
       
        </div>
    </body>

</html>