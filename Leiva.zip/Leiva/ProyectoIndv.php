<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Mi Proyecto</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type="text/css" media="screen" href="css/navbar.css">
        <link rel="stylesheet" type="text/css" media="screen" href="css/main.css">
        <link rel="stylesheet" type="text/css" media="screen" href="css/main.css">
        <script src="main.js"></script>
    </head>
    <header>
        <div class="topnav">
        <img class="logo" src="images/leivaLogoPequeño.png" alt="LOGO" href="index.html" width=100px>
        <nav>
            <ul>
               
                    <li><a class="link" href="index.php">INICIO</a></li>
                    <li><a class="active" href="misProyectos.php">MIS PROYECTOS</a></li>
                    <li><a class="link" href="index.php">CATÁLOGO</a></li>
                    <li><a class="link" href="about.php">SOBRE NOSOTROS</a></li>
                    <li class="carrito"><a href="index.php"><img src="images/carrito.png" alt="CARRITO"></a></li>
                    <li class="perfil"><a href="index.php"><img src="images/loggedUser.png" alt="PERFIL"></a></li>
    
            </ul>
    
        </nav>
        </div>
    </header>

    <body>
        <h1>Mis Proyectos</h1>
        <div class="contenedor">
            <div class="item"> <!--Parte izq pagina con titulo, descripcion, boton y valoracion-->
                <div>
                    <p1>Silla Moderna</p1><br>
                    <div class="descr">Un diseño innovador, que ofrece una gran estabilidad, y muy confortable, adaptándose perfectamente a tu cuerpo. Incorpora además un cómodo cojín integrado, tapizado en polipiel de alta calidad. El respaldo está fabricado en polipropileno flexible y resistente, y las patas en madera de haya, llegando a soportar hasta 150 Kg. Los materiales son resistentes y fáciles de limpiar con un paño húmedo y jabón neutro.</div>
                </div>
                    <textarea class="comentarioMueble" placeholder="Escriba un comentario..."></textarea><br> <!--Cuadro texto-->
                <div class="valoracion">
                    <form>
                        <p2>Valoración:</p2>
                     
                        <p class="clasificacion"> <!--Estrellas-->
                            <input id="radio1" type="radio" name="estrellas" value="5"><!--
                                --><label for="radio1">★</label><!--
                                --><input id="radio2" type="radio" name="estrellas" value="4"><!--
                                --><label for="radio2">★</label><!--
                                --><input id="radio3" type="radio" name="estrellas" value="3"><!--
                                --><label for="radio3">★</label><!--
                                --><input id="radio4" type="radio" name="estrellas" value="2"><!--
                                --><label for="radio4">★</label><!--
                                --><input id="radio5" type="radio" name="estrellas" value="1"><!--
                                --><label for="radio5">★</label>
                            <input name="boton" type="button" value="Enviar">
                        </p>

                    </form>
                </div>
            </div>

            <div class="item">
                <p3>imagenes</p3>
                <a href="ProyectoIndv.html"><img class="plus" src="images/plus.png" style="width: 3%;"></a><br>
                <div class="fondoImagenes">
                    
                    <img class="foto" src="images/silla.png" >
                    <img class="foto" src="images/silla2.jpg">
                    <img class="foto" src="images/silla.png" >
                    <img class="foto" src="images/silla2.jpg">
                    <img class="foto" src="images/silla2.jpg">
                    <img class="foto" src="images/silla2.jpg">
                    <img class="foto" src="images/silla.png" >
                    <img class="foto" src="images/silla2.jpg">
                    <img class="foto" src="images/silla.png" >
                    <img class="foto" src="images/silla2.jpg">
                    <img class="foto" src="images/silla2.jpg">
                    <img class="foto" src="images/silla2.jpg">    
                </div>
            </div>
       
        </div>
        
        
        


        
        

    </body>

</html>