﻿<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Sobre Nosotros</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="css/navbar.css">
    <link rel="stylesheet" type="text/css" media="screen" href="css/main.css">
    <link rel="stylesheet" type="text/css" media="screen" href="css/about.css">
    <script src="main.js"></script>
</head>
<header>

	<div class="topnav" id ="myTopnav">
		<img class="logo" src="images/leivaLogoPequeño.png" alt="LOGO" href="index.html" width=100px>
		<a href="about.php" class="active">Sobre nosotros</a>
		<a href="#news">Catalogo</a>
		<a href="misProyectos.php">Mis proyectos</a>
		<a href="index.php">Inicio</a>
		<a href="javascript:void(0);" class="icon" onclick="myFunction()">
		<i class="fa fa-bars"></i>
		</a>
  	</div>
	
	<script>
		function myFunction() {
		var x = document.getElementById("myTopnav");
		if (x.className === "topnav") {
		x.className += " responsive";
		} else {
		x.className = "topnav";
		}
	    }
	</script>
</header>
<body>
    <div class="grid">
        
            <div class="grid-item"><img src="images/fondoAboutD.jpg"> </div>
                <div class="grid-item" id="container">
                    <h1><ins>INFORMACIÓN</ins></h1>
                    <table><tr class="espasio"></tr> </table>
                    <table>
                        <tr>
                            <td><img src="images/ubi.png" height="75px"></td>
                            <td><a href="https://goo.gl/maps/T7hpkstuSLv">Calle Maestro Falla nº5 <br/> 41940. Sevilla</a></td>
                        </tr>
                        <tr class="espasio"></tr>
                        <tr>
                            <td><img src="images/tlf.png" height="75px"></td>
                            <td>954636936</td>
                        </tr>
                        <tr class="espasio"></tr>
                        <tr>
                            <td><img src="images/mail.png" height="75px"></td>
                            <td>leivamueble@gmail.com</td>
                        </tr>

                    </table>
                </div>
            <div class="grid-item"><img src="images/fondoAboutI.jpg"> </div>
        
    </div>
</body>
</html>