﻿<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Sobre Nosotros</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <link rel="stylesheet" type="text/css" media="screen" href="css/about.css">
   
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
	<link rel="stylesheet" href="css/navbar2.css" type="text/css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
  
</head>
<body>


    <?php
	include_once 'cabecera.php';
?>



    <div class="grid2">
        
                <div class="grid-item2" id="foto"><img src="images/fondoAboutD.jpg" width="40%" style="float: left" ></div>
                <div class="grid-container2" id="container2"  >
                    <h1><ins>INFORMACIÓN</ins></h1>
                    <table><tr class="espasio2"></tr> </table>
                    <table>
                        <tr>
                            <td><img src="images/ubi.png" height="75px"></td>
                            <td><a href="https://goo.gl/maps/T7hpkstuSLv" style="color:black">Calle Maestro Falla nº5 <br/> 41940. Sevilla</a></td>
                        </tr>
                        <tr class="espasio2"></tr>
                        <tr>
                            <td><img src="images/tlf.png" height="75px"></td>
                            <td>954636936</td>
                        </tr>
                        <tr class="espasio2"></tr>
                        <tr>
                            <td><img src="images/mail.png" height="75px"></td>
                            <td>leivamueble@gmail.com</td>
                        </tr>

                    </table>
                </div>
                <div class="grid-item2" id="foto"><img src="images/fondoAboutI.jpg"width="40%" style="float: left"  ></div>
        
    </div>
</body>
</html>