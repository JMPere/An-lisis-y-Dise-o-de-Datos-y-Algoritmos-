
<?php	
	session_start();	
	
	if (isset($_SESSION["cambioUsuario"])) {
		$datos = $_SESSION["cambioUsuario"];
		unset($_SESSION["cambioUsuario"]);
		
	require_once("gestionBD.php");
	require_once("gestionarUsuarios.php");
		
		$conexion = crearConexionBD();		
		$excepcion = modificarUsuario($conexion,$datos['OID_USUARIO'], $datos['NOMBRE'], 
				$datos['APELLIDOS'], $datos['DIRECCION'], $datos['NICKNAME'], $datos['NUEVA_CONTRASEÑA']);
		cerrarConexionBD($conexion);
			
		if ($excepcion<>"") {
			$_SESSION["excepcion"] = $excepcion;
			$_SESSION["destino"] = "perfil.php";
			Header("Location: excepcion.php");
		}
		else
			Header("Location: perfil.php");
	} 
	else Header("Location: perfil.php"); // Se ha tratado de acceder directamente a este PHP
?>

