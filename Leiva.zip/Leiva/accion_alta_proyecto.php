<?php
session_start();

// Importamos las clases de gestion de usuarios y base de datos
require_once ("gestionBD.php");
require_once ("gestionarProyectos.php");
// Comprobamos que se ha rellenado el formulario, si no volvemos a este
if (isset($_SESSION["creaProyecto"])) {
	$creaProyecto = $_SESSION["creaProyecto"];
	unset($_SESSION["creaProyecto"]);
	unset($_SESSION["errores"]);
} else
	Header("Location:creaProyecto.php");

// ABRIR LA CONEXIÓN A LA BASE DE DATOS
$conexion = crearConexionBD();
?>

<!DOCTYPE html>
<html lang="es">
	<head>
		<meta charset="utf-8">
		<title>Mobiliaria Leiva - Proyecto creado con éxito</title>
		<link rel="stylesheet" type="text/css" media="screen" href="css/navbar2.css">
		<link rel="stylesheet" type="text/css" media="screen" href="css/main.css">
	</head>

	<body>
		<?php
	include_once 'cabecera.php';
?>


		<main>

			<!--CONSULTAR EL TEMA DE TEORÍA SOBRE ACCESO A DATOS -->
			<?php

if (alta_Proyecto($conexion, $creaProyecto)==true) {
			?>
			<!-- MENSAJE DE BIENVENIDO AL PROYECTO -->
			<div>
				<h1 style="color: black">Proyecto: <?php echo $creaProyecto["NOMBRE"] ?>
				listo, gracias por su confianza.</h1>
			</div>
			<?php } else { ?>
			<!-- MENSAJE DE QUE PROYECTO YA EXISTE -->
			<h1 style="color: black">El proyecto <?php echo $creaProyecto["NOMBRE"] ?>
			ya existe en la base de datos.</h1>
			<div  style="color: black">
				Pulse <a style="color: black" href="creaProyecto.php">aquí</a> para volver al formulario.
			</div>
			<?php } ?>
		</main>

	</body>
</html>
<?php
// DESCONECTAR LA BASE DE DATOS
cerrarConexionBD($conexion);
?>