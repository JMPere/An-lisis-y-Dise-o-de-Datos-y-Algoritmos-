<?php
	session_start();

	// Importamos las clases de gestion de usuarios y base de datos
	require_once("gestionBD.php");
	require_once("gestionarUsuarios.php");
	// Comprobamos que se ha rellenado el formulario, si no volvemos a este
	if (isset($_SESSION["formulario"])) {
		$formulario = $_SESSION["formulario"];
		unset ($_SESSION["formulario"]);
		unset ($_SESSION["errores"]);
	} else Header("Location:registrarse.php");
		
	// ABRIR LA CONEXIÓN A LA BASE DE DATOS
	$conexion = crearConexionBD();

?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Mobiliaria Leiva - Registro realizado con éxito</title>
   <link rel="stylesheet" type="text/css" media="screen" href="css/navbar2.css">
   <link rel="stylesheet" type="text/css" media="screen" href="css/main.css">
</head>

<body>
	<?php
	include_once 'cabecera.php';
?>


	<main>
		<!-- CONSULTAR EL TEMA DE TEORÍA SOBRE ACCESO A DATOS -->
		<?php 
			if (alta_Usuario($conexion, $formulario)==true) {
		?>
				<!-- MENSAJE DE BIENVENIDO AL USUARIO -->
			<div>
				<h1 style="color: black">Hola <?php echo $formulario["NOMBRE"] ?>, gracias por registrarte.</h1>
			</div>
		<?php } else { ?>
				<!-- MENSAJE DE QUE USUARIO YA EXISTE -->
				<h1 style="color: black">El usuario <?php echo $formulario["NOMBRE"] ?> ya existe en la base de datos.</h1>
				<div  style="color: black">	
					Pulse <a style="color: black" href="registrarse.php">aquí</a> para volver al formulario.
				</div>
		<?php } ?>
	</main>

</body>
</html>
<?php
	// DESCONECTAR LA BASE DE DATOS
	cerrarConexionBD($conexion);
?>

