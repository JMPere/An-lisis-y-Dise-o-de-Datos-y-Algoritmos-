<?php
session_start();
include_once ("gestionBD.php");
include_once ("gestionarProyectos.php");
include_once ("gestionarModificacionProyecto.php");

$nuevaValoracion["DESCRIPCION"] = $_POST["DescripcionModificada"];
$nuevaValoracion["VALORACION"] = $_POST["estrellas"];
$nuevaValoracion["OID_PROYECTO"]=$_SESSION["OID_PROYECTO"];

$conexion = crearConexionBD();
alta_modificacion_proyecto($conexion, $nuevaValoracion);
$conexion = cerrarConexionBD($conexion);
Header("Location:ProyectoIndv.php");

?>








