<?php	
	session_start();	
	
	if (isset($_SESSION["borrarMueble"])) {
		$datos = $_SESSION["borrarMueble"];
		unset($_SESSION["borrarMueble"]);
		
	require_once("gestionBD.php");
	require_once("gestionarMuebles.php");
		
		$conexion = crearConexionBD();		
		$excepcion = quitar_mueble($conexion,$datos["OID_MUEBLE"]);
		cerrarConexionBD($conexion);
			
		if ($excepcion<>"") {
			$_SESSION["excepcion"] = $excepcion;
			$_SESSION["destino"] = "administrador.php";
			Header("Location: excepcion.php");
		}
		else
			Header("Location: administrador.php");
	} 
	else Header("Location: administrador.php"); // Se ha tratado de acceder directamente a este PHP
?>