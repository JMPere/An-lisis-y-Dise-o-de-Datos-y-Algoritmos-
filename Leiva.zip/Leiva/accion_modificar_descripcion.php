<?php	
	session_start();	
	
	$_SESSION["modificar"]=TRUE;
	Header("Location:ProyectoIndv.php");
	/*ESTO ES ASI DE CORTO, NO ES QUE ESTÉ POR ESTAR XDD*/
?>