<?php	
	session_start();	
	
	if (isset($_SESSION["cambiarPer"])) {
		$datos = $_SESSION["cambiarPer"];
		unset($_SESSION["cambiarPer"]);
		
	require_once("gestionBD.php");
	require_once("gestionarUsuarios.php");
		
		$conexion = crearConexionBD();		
		$excepcion = modificarPermisoUsuario($conexion,$datos['OID_USUARIO'], $datos['PERMISO']);
		cerrarConexionBD($conexion);
			
		if ($excepcion<>"") {
			$_SESSION["excepcion"] = $excepcion;
			$_SESSION["destino"] = "administrador.php";
			Header("Location: excepcion.php");
		}
		else
			Header("Location: administrador.php");
	} 
	else Header("Location: administrador.php"); // Se ha tratado de acceder directamente a este PHP
?>