<?php
session_start();

require_once ("gestionBD.php");
require_once ("gestionarMuebles.php");
require_once ("gestionarUsuarios.php");

if (!isset($_SESSION["login"])) {
	Header("Location:login.php");
}
if (isset($_REQUEST["oid"])) {
	$cambiarPer['OID_USUARIO'] = $_REQUEST["oid"];
	$cambiarPer['PERMISO'] = $_REQUEST["permiso"];
	$_SESSION["cambiarPer"] = $cambiarPer;
	Header("Location:accion_modificar_permiso.php");
}
if (isset($_REQUEST["oidmueble"])) {
	$borrarMueble['OID_MUEBLE'] = $_REQUEST["oidmueble"];
	$_SESSION["borrarMueble"] = $borrarMueble;
	Header("Location:accion_borrar_mueble.php");
}

$conexion = crearConexionBD();
$totalMuebles = consultarTodosMuebles($conexion);
$totalUsuarios = consultarTodosUsuarios($conexion);
$conexion = cerrarConexionBD($conexion);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Mobiliaria Leiva - Mis Proyectos</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="css/main.css">
    <link rel="stylesheet" type="text/css" media="screen" href="css/navbar2.css">
    <script src="main.js"></script>
</head>
<body>
<?php
	include_once 'cabecera.php';
?>

        

    <div class="tabla">
    <table class="proyectos" style="width:98%">
        <tr>
            <th>Nombre Mueble</th>
            <th>Opciones</th>
        </tr>
		<?php
		foreach($totalMuebles as $mueble) {
		?>
        
        <tr>
        	<form method='post' action="administrador.php">
        	<td><?php echo $mueble["NOMBREMUEBLE"]; ?></td>
        	<input type="hidden" name="oidmueble" value="<?php echo $mueble["OID_MUEBLE"]; ?>" />
        	<td><input type="submit" value="Borrar">
        	<input type="submit" value="Modificar"></td>
        	</form>
        </tr>
        
        <?php
		}
		?>
    </table>
    </div>

    <div class="tabla">
            <table class="proyectos" style="width:98%">
                <tr>
                    <th>Usuario</th>
                    <th>Permisos</th>
                    <th>Opciones</th>
                </tr>
				<?php
				foreach($totalUsuarios as $usuario) {
					if ($usuario != $_SESSION["login"]){
				?>
        
        		<tr>
        			<td><?php echo $usuario["NICKNAME"]; ?></td>
        			<td><?php
						if ($usuario["PERMISO"] == 'Y') {
							echo "Admin";

						} else {

							echo "Cliente";

						}
					?></td>
          			<td>
          			<form method='post' action="administrador.php">
          				<input type="hidden" name="oid" value="<?php echo $usuario["OID_USUARIO"]; ?>" />
          				<input type="hidden" name="permiso" value="<?php echo $usuario["PERMISO"]; ?>" />
					
          				<input type="submit" value="Cambiar permisos"
          				
						></form></td>
       			</tr>
        
        		<?php
				}
				}
				?>
            </table>
            </div>
</body>
</html>