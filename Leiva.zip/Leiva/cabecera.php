<!--<header>
	<div class="topnav" id ="myTopnav">
		<img class="logo" src="images/leiva logo pequeño 2.jpg" alt="LOGO" href="index.html" style=" width:9% ">
		<a id="about" href="about.php">Sobre nosotros</a>
		<a id="catalogo" href="catalogo.php">Catalogo</a>
		<a id="misProyectos" href="misProyectos.php">Mis proyectos</a>
		<a id="index" href="index.php">Inicio</a>
		<a id="perfil" href="perfil.php"><img src="images/loggedUser.png" style="width: 68%" /></a>
		<a id="icon" href="javascript:void(0);" class="icon" onclick="myFunction()"> <i class="fa fa-bars"></i> </a>
	</div>

	<script>
		function myFunction() {
			var x = document.getElementById("myTopnav");
			if (x.className === "topnav") {
				x.className += " responsive";
			} else {
				x.className = "topnav";
			}
		}
	</script>

</header> -->

<nav>
  <ul>
  	<li>
  		<img class="logo" src="images/leiva logo pequeño 2.jpg" alt="LOGO" href="index.html" style=" width:130px ">
  	</li>
  	
  	
    <li>
      <a href="index.php">Inicio</a>
    </li>
    <li>
      <a href="catalogo.php">Catálogo</a>
    </li>
    <li>
      <a href="misProyectos.php">Mis Proyectos</a>
    </li>
    <li>
      <a href="about.php">Sobre Nosotros</a>
    </li>
   	<li>
  		
  		<a href="perfil.php"><img src="images/user.png" ></a>
  	</li>
   	<li>
  		
  		<a href="perfil.php"><img src="images/carritoFinal.png" style="width: 32px"></a>
  	</li>
</ul>
</nav>