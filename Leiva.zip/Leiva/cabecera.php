<header>
	<div class="topnav" id ="myTopnav">
		<img class="logo" src="images/leiva logo pequeño 2.jpg" alt="LOGO" href="index.html" style=" width: ">
		<a href="about.php">Sobre nosotros</a>
		<a href="#news">Catalogo</a>
		<a href="misProyectos.php">Mis proyectos</a>
		<a href="index.php" class="active">Inicio</a>
		<a href="javascript:void(0);" class="icon" onclick="myFunction()"> <i class="fa fa-bars"></i> </a>
	</div>

	<script>
		function myFunction() {
			var x = document.getElementById("myTopnav");
			if (x.className === "topnav") {
				x.className += " responsive";
			} else {
				x.className = "topnav";
			}
		}
	</script>

</header>
