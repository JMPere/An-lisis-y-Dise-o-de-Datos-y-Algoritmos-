<?php
session_start();

require_once ("gestionBD.php");
require_once ("gestionarMuebles.php");

if (!isset($_SESSION["login"])) {
	Header("Location:login.php");
}

$conexion = crearConexionBD();
$totalMuebles = consultarTodosMuebles($conexion);
$conexion = cerrarConexionBD($conexion);
?>


<!-- =======HTML======= -->

<!DOCTYPE html>
<html>
<head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
        <link rel="stylesheet" href="css/navbar2.css" type="text/css">
        <link rel="stylesheet" href="css/main.css" type="text/css">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">    
        <title>Leiva - Catálogo</title>  
    </head>

	<body>
<?php
	include_once 'cabecera.php';
?>

 

        
                  
        <div class="catalogo_contenedor">        
            <div class = "filtros">
                    <div class="filtros_margen">
                        <form action="./catalogo.html" method="post" class="filtros_form">
                            <div class="filtros_busqueda">
                                <input type="text"><input type="submit" value="Buscar"><br><br><br>
                            </div> 
                            <input type="checkbox" name="zona" value="Bike"> Comedor<br><br>
                            <input type="checkbox" name="zona" value="Car" > Cocina<br><br>
                            <input type="checkbox" name="zona" value="Bike"> Salón<br><br>
                            <input type="checkbox" name="zona" value="Car" > Dormitorio<br><br>
                            <input type="checkbox" name="zona" value="Bike"> Baño<br><br>
                            <input type="submit" class="filtros_filtrar" value="Filtrar">
                        </form>

                    </div>
                    
        
            </div>

            <div class="productos">
				<?php

				$index = 0;
				foreach($totalMuebles as $mueble) {
				?>
                <div class="div-imagen"><div class="producto_descripcion">
                	<?php
                		echo $mueble["DESCRIPCION"];
                	?></div>
						<input id="OID_MUEBLE" name="OID_MUEBLE" type="hidden"
						value="<?php echo $mueble["OID_MUEBLE"]; ?>"/>
						<?php $imagen = "imageMueble/" . $mueble["IMAGEN"] . ".jpg"; ?>
						<input id="IMAGEN" class="desvanecer "type="image" src="<?php echo $imagen; ?>" alt="submit">
                </div>
                    
				<?php
				}
				?>
            </div>
        </div>  
	</body>
</html>