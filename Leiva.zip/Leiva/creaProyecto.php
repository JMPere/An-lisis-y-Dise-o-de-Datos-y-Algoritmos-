	
	<?php
		session_start();
		if (!isset($_SESSION['proyecto'])) {
			$proyecto['NOMBRE'] = "";
			$proyecto['DESCRIPCION'] = "";
			$proyecto['FECHA_INICIO'] = "";
			$proyecto['FECHA_FINAL'] = "";
			$proyecto['VALORACION'] = "";
			$proyecto['DURACION'] = "";
			$proyecto['ESTADO'] = "";
			$proyecto['PERMISO'] = "";
			$proyecto['OID_CLIENTE'] = "";
			$proyecto['OID_EMPLEADO'] = "";
			
			$_SESSION['proyecto'] = $proyecto;
		}else
			$proyecto = $_SESSION['proyecto'];

			// Si hay errores de validación, hay que mostrarlos y marcar los campos (El estilo viene dado y ya se explicará)
			if (isset($_SESSION["errores"]))
				$errores = $_SESSION["errores"];
?>
	?>




<!DOCTYPE html>
<!--Este es mi index-->
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Creación de Proyecto</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="css/navbar.css">
    <link rel="stylesheet" type="text/css" media="screen" href="css/main.css">
    
    <script src="main.js"></script>
</head>
<body>
	
	
	
	
    <header>
	<div class="topnav" id ="myTopnav">
		<img class="logo" src="images/leiva logo pequeño 2.jpg" alt="LOGO" href="index.html" style=" width: ">
		<a href="about.php">Sobre nosotros</a>
		<a href="#news">Catalogo</a>
		<a href="misProyectos.php" class="active">Mis proyectos</a>
		<a href="index.php" >Inicio</a>
		<a href="javascript:void(0);" class="icon" onclick="myFunction()"> <i class="fa fa-bars"></i> </a>
	</div>

	<script>
		function myFunction() {
			var x = document.getElementById("myTopnav");
			if (x.className === "topnav") {
				x.className += " responsive";
			} else {
				x.className = "topnav";
			}
		}
	</script>

	</header>

	<?php

		if (isset($errores) && count($errores) > 0) {
			echo "<div id=\"div_errores\" class=\"error\">";
			echo "<h4> Errores en el formulario:</h4>";
		foreach ($errores as $error)
			echo $error;
		echo "</div>";
	}
	?>
	

    <h1> ¡Crea tu propio mueble!</h1>
    <div class = "fondoCuadro">
 
		<form action="validacion_alta_proyecto.php" method="post">
	        <div class="NomProy">Nombre del proyecto: 
	            <input name="nom" type="text" id ="nom" required=""><br><br><br> <!-- nombre proyecto-->
	            <textarea name="Descripcion" placeholder="Inserte detalles del mueble..." resize="none" id="Descripcion" required></textarea> <!-- descripcion proyecto-->
	
	        </div><br>
	        <div class="adjunto">¿Quieres añadir alguna imagen?:   
	            <img src="images/clip.png" width="3%">
	        </div>
	        <br><br>
	        <input type="submit" name="boton" value="Enviar" size="100px">
	    </form>
     
    </div>
    

</body>
</html>