<?php
session_start();
if (!isset($_SESSION['creaProyecto'])) {
	$creaProyecto['NOMBRE'] = "";
	$creaProyecto['DESCRIPCION'] = "";
	$creaProyecto['FECHA_INICIO'] = "";
	$creaProyecto['FECHA_FINAL'] = "";
	$creaProyecto['VALORACION'] = "";
	$creaProyecto['DURACION'] = "";
	$creaProyecto['ESTADO'] = "";
	$creaProyecto['PERMISO'] = "";
	$creaProyecto['OID_CLIENTE'] = "";
	$creaProyecto['OID_EMPLEADO'] = "";

	$_SESSION['creaProyecto'] = $creaProyecto;
} else
	$creaProyecto = $_SESSION['creaProyecto'];

// Si hay errores de validación, hay que mostrarlos y marcar los campos (El estilo viene dado y ya se explicará)
if (isset($_SESSION["errores"]))
	$errores = $_SESSION["errores"];
?>

<!DOCTYPE html>
<!--Este es mi index-->
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>Creación de Proyecto</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" type="text/css" media="screen" href="css/navbar2.css">
		<link rel="stylesheet" type="text/css" media="screen" href="css/creaProy.css">

		<script src="main.js"></script>
	</head>
	<body>

		<?php
	include_once 'cabecera.php';
?>


		<form action="validacion_alta_proyecto.php" method="post">
			<h2>¡Crea Tu Propio Mueble!</h2>
			<div class="large-group">
				<div class="small-group">
					<label for="nom">Nombre Proyecto</label>
					<input name="nom" type="text" id ="nom" required>
				</div>

				<div class="small-group">
					<label for="fechafin">Fecha estimada para finalizar el proyecto</label>
					<input name="fechafin" id="fechafin" for="fechafin" type="date" required/>
				</div>
				<div class="small-group">
					<label for="duracion">Tiempo del Proyecto</label>
					<select name="duracion" id="duracion" for="duracion">
						<option value="1">Corto</option>
						<option value="2">Medio</option>
						<option value="3">Largo</option>
					</select>
				</div>

				<div class="small-group">
				<div class="peq">
					<label for="permiso">Uso como publicidad</label>
					<select name="permiso" id="permiso" for="permiso">
						<option value="Y">Sí</option>
						<option value="N">No</option>
					</select>
					</div><div class="der">
					<label style="padding-right: 8px" for="plazos">Número de plazos a pagar</label>
					<select name="plazos" id="plazos" for="plazos">
						<option value="1">1 plazo</option>
						<option value="2">2 plazos</option>
						<option value="4">4 plazos</option>
					</select>
				</div></div>

				<div class="textarea-div">
					<label for="Descripcion">Descripción</label>
					<textarea  for="Descripcion"id="Descripcion" type="text" placeholder="Inserte detalles del mueble..." name="Descripcion" required></textarea>
				</div>

				<input id="submit" class="btn" type="submit" name="submit"/>

			</div>
		</form>
			<?php

		if (isset($errores) && count($errores) > 0) {
			echo "<div id=\"div_errores\" class=\"error\">";
			echo "<h4> Errores en el formulario:</h4>";
		foreach ($errores as $error)
			echo $error;
		echo "</div>";
	}
	?>
	

	</body>
</html>