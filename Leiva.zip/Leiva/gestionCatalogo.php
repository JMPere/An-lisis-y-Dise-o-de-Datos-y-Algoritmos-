<?php
session_start();
if (!isset($_SESSION['muebleCatalogo'])) {
	$muebleCatalogo['NOMBRE'] = "";
	$muebleCatalogo['DESCRIPCION'] = "";
	$muebleCatalogo['PRECIO'] = "";
	$muebleCatalogo['IMAGEN'] = "";
	$muebleCatalogo['STOCK'] = "";

	$_SESSION['muebleCatalogo'] = $muebleCatalogo;
} else
	$muebleCatalogo = $_SESSION['muebleCatalogo'];

// Si hay errores de validación, hay que mostrarlos y marcar los campos (El estilo viene dado y ya se explicará)
//if (isset($_SESSION["errores"]))
//	$errores = $_SESSION["errores"];
?>

<!DOCTYPE html>
<!--Este es mi index-->
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>Insertar a Catálogo</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" type="text/css" media="screen" href="css/navbar2.css">
		<link rel="stylesheet" type="text/css" media="screen" href="css/creaProy.css">

		<script src="main.js"></script>
	</head>
	<body>

		<?php
	include_once 'cabecera.php';
	?>

		<form action="validacion_mueble_catalogo.php" method="post">
			<h2>Insertar mueble al catálogo</h2>
			<div class="large-group">
				<div class="small-group">
					<label for="nom">Nombre Mueble</label>
					<input name="nom" type="text" id ="nom" required>
				</div>

				<div class="small-group">
					<label style="padding-right: 8px" for="precio">Precio</label>
					<input type="number"  name="precio" min="0" value="0.00" step="any" id="precio" required>
				</div>
				
				<div class="small-group">
					<label style="padding-right: 8px" for="imagen">Imagen</label>
					<input name="imagen" type="text" id ="imagen" required>
				</div>

				<div class="small-group">

					<div class="peq">
						<label style="padding-right: 8px" for="stock">Stock</label>
						<input name="stock" type="number" min="0" value="0" id ="stock" required>
					</div>
				</div>

				<div class="textarea-div">
					<label for="Descripcion">Descripción</label>
					<textarea  for="Descripcion"id="Descripcion" style="resize: none" type="text" placeholder="Inserte detalles del mueble..." name="Descripcion" required></textarea>
				</div>

				<input id="submit" class="btn" type="submit" name="submit"/>

			</div>
		</form>
		<?php

		if (isset($errores) && count($errores) > 0) {
			echo "<div id=\"div_errores\" class=\"error\">";
			echo "<h4> Errores en el formulario:</h4>";
			foreach ($errores as $error)
				echo $error;
			echo "</div>";
		}
		?>
	</body>
</html>