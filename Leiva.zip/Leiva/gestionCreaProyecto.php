<?php

function alta_proyecto($conexion, $proyecto){
	
	$sql="INSERT INTO PROYECTO(NOMBRE, DESCRIPCION, FECHA_INICIO, FECHA_FINAL,VALORACION,DURACION,NUMPLAZOS,ESTADO,PERMISO,OID_CLIENTE,OID_EMPLEADO)
			VALUES(:NOMBRE, :DESCRIPCION, :FECHA_INICIO, :FECHA_FINAL,:VALORACION,:DURACION,:NUMPLAZOS,:ESTADO,:PERMISO,:OID_CLIENTE,:OID_EMPLEADO);";
			
	$stmt=$conexion->prepare($sql);
	$stmt->bindParam(':NOMBRE',$usuario["NOMBRE"]);
	$stmt->bindParam(':NICKNAME',$usuario["NICKNAME"]);
	$stmt->bindParam(':APELLIDOS',$usuario["APELLIDOS"]);
	$stmt->bindParam(':CORREO',$usuario["CORREO"]);
	$stmt->bindParam(':FECHA_NACIMIENTO',$fechaNacimiento);
	$stmt->bindParam(':CONTRASEÑA',$usuario["CONTRASEÑA"]);
	$stmt->bindParam(':DIRECCION',$usuario["DIRECCION"]);
	
	return true;
	}


?>