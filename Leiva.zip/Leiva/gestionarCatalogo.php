<?php
  /*
     * #===========================================================#
     * #	Este fichero contiene las funciones de gestión
     * #	de proyecto de la capa de acceso a datos
     * #==========================================================#
     */

    
     
 function alta_Catalogo($conexion,$muebleCatalogo) {
	
	if (!isset($_SESSION["login"])) {
	Header("Location:login.php");
	} 
	$usuario = $_SESSION["login"];
	
	try {
		/*$consulta = "INSERT INTO PROYECTO(NOMBRE, DESCRIPCION, FECHA_INICIO, FECHA_FINAL,VALORACION,DURACION,NUMPLAZOS,ESTADO,PERMISO,OID_CLIENTE,OID_EMPLEADO)
					VALUES(':NOMBRE' , ':DESCRIPCION' , DATE ':FECHA_INICIO' , DATE ':FECHA_FINAL' , :VALORACION ,
		 :DURACION , :NUMPLAZOS , :ESTADO , ':PERMISO' ,5,1)";*/
		 
		 $consulta = "CALL INSERTAR_MUEBLE(:NOMBRE, :DESCRIPCION, :PRECIO, :IMAGEN,  :STOCK)";

	//	$consulta = "INSERT INTO MUEBLE(nombremueble, descripcion, imagen, precio, stock) VALUES(:NOMBRE, :DESCRIPCION, :IMAGEN, :PRECIO, :STOCK)";
		
		$stmt=$conexion->prepare($consulta);
		$stmt->bindParam(':NOMBRE',$muebleCatalogo["NOMBRE"]);
		$stmt->bindParam(':DESCRIPCION',$muebleCatalogo["DESCRIPCION"]);
		$stmt->bindParam(':IMAGEN',$muebleCatalogo["IMAGEN"]);
		$stmt->bindParam(':PRECIO',$muebleCatalogo["PRECIO"]);
		$stmt->bindParam(':STOCK',$muebleCatalogo["STOCK"]);
		
		

		
	
		$stmt->execute();	
		return true;

	} catch(PDOException $e) {
		
		return false;
		// $_SESSION['excepcion'] = $e->GetMessage();
		//Header("Location: excepcion.php");
	}
}

?>
