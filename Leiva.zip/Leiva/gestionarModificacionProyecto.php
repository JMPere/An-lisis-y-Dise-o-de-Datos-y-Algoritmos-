<?php
  /*
     * #===========================================================#
     * #	Este fichero contiene las funciones de gestión
     * #	de usuarios de la capa de acceso a datos
     * #==========================================================#
     */

 function alta_modificacion_proyecto($conexion,$modificacion) {

	
	try {
	
	
	echo $modificacion["OID_PROYECTO"];
	echo $modificacion["DESCRIPCION"];
	echo $modificacion["VALORACION"];

	
	return true;

	} catch(PDOException $e) {
		return false;
	}
}
 ?>