<?php
  /*
     * #===========================================================#
     * #	Este fichero contiene las funciones de gestión     			 
     * #	de muebles de la capa de acceso a datos 		
     * #==========================================================#
     */
     
function consultarTodosMuebles($conexion) {
	$consulta = "SELECT * FROM MUEBLE WHERE (MUEBLE.STOCK > 0) ORDER BY NOMBREMUEBLE";
    return $conexion->query($consulta);
}
 
function quitar_mueble($conexion,$oid_mueble) {
    try {
        $stmt=$conexion->prepare('CALL QUITAR_MUEBLE(:oid_mueble)');
        $stmt->bindParam(':oid_mueble',$oid_mueble);
        $stmt->execute();
        return "";
    } catch(PDOException $e) {
        return $e->getMessage();
    }
}
 /*
function modificar_mueble($conexion,$OidMueble,$nombreMueble) {
	try {
		$stmt=$conexion->prepare('CALL MODIFICAR_TITULO(:OidLibro,:TituloLibro)');
		$stmt->bindParam(':OidLibro',$OidLibro);
		$stmt->bindParam(':TituloLibro',$TituloLibro);
		$stmt->execute();
		return "";
	} catch(PDOException $e) {
		return $e->getMessage();
    }
}*/
	
?>