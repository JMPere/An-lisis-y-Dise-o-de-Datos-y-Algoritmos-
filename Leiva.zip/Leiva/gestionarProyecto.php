<?php
  /*
     * #===========================================================#
     * #	Este fichero contiene las funciones de gestión
     * #	de proyecto de la capa de acceso a datos
     * #==========================================================#
     */

 function alta_Proyecto($conexion,$proyecto) {
	
	try {
		/*$consulta = "INSERT INTO PROYECTO(NOMBRE, DESCRIPCION, FECHA_INICIO, FECHA_FINAL,VALORACION,DURACION,NUMPLAZOS,ESTADO,PERMISO,OID_CLIENTE,OID_EMPLEADO)
					VALUES(':NOMBRE' , ':DESCRIPCION' , DATE ':FECHA_INICIO' , DATE ':FECHA_FINAL' , :VALORACION ,
		 :DURACION , :NUMPLAZOS , :ESTADO , ':PERMISO' ,5,1)";*/
		 
		 $consulta = "INSERT INTO PROYECTO(NOMBRE, DESCRIPCION, FECHA_INICIO, FECHA_FINAL,VALORACION,DURACION,NUMPLAZOS,ESTADO,PERMISO,OID_CLIENTE,OID_EMPLEADO)
			VALUES(':nom',':desc',DATE ':fechini',DATE ':fechfin',
			:val,:dur,:num,:est,':per',5,1)";
		 
		
		foreach ($proyecto as $valores) {
			echo $valores."<br>";
		}
		$nombre='asdsad';$desci='asdsad';
		$fechinii= 2019-02-05;
		$fechifin= 2019-02-15;
		$a=4;
		$s=3;
		$v=4;
		$f=3;
		$ew='Y';
		$stmt=$conexion->prepare($consulta);
		$stmt->bindParam(':nom',$nombre);
		$stmt->bindParam(':desc',$desci);
		$stmt->bindParam(':fechini',$fechinii);
		$stmt->bindParam(':fechfin',$fechifin);
		$stmt->bindParam(':val',$a);
		$stmt->bindParam(':dur',$s);
		$stmt->bindParam(':num',$v);
		$stmt->bindParam(':est',$f);
		$stmt->bindParam(':per',$ew);
		echo $consulta;
	
		$stmt->execute();	
		return true;

	} catch(PDOException $e) {
		
		return false;
		// $_SESSION['excepcion'] = $e->GetMessage();
		//Header("Location: excepcion.php");
	}
}

function consultarProyecto($conexion,$nombre) {
	$consulta= "SELECT COUNT(*)AS TOTAL "
				."FROM PROYECTO "
				."WHERE NOMBRE=:nombre";
	$stmt = $conexion->prepare($consulta);
	$stmt -> bindParam(":nombre", $nombre);
	$stmt -> execute();
	return $stmt->fetchColumn();

}