<?php
  /*
     * #===========================================================#
     * #	Este fichero contiene las funciones de gestión
     * #	de proyecto de la capa de acceso a datos
     * #==========================================================#
     */

 function alta_Proyecto($conexion,$proyecto) {
	
	try {
		$consulta = "INSERT INTO PROYECTO(NOMBRE, DESCRIPCION,FECHA_INICIO, FECHA_FINAL,VALORACION,DURACION,
		NUMPLAZOS,ESTADO,PERMISO,OID_CLIENTE,OID_EMPLEADO)
		VALUES( ':NOMBRE' , ':DESCRIPCION' , DATE ':FECHA_INICIO' , DATE ':FECHA_FINAL' , ':VALORACION' ,
		 ':DURACION' , ':NUMPLAZOS' , ':ESTADO' , ':PERMISO' ,5,1)";
		
		foreach ($proyecto as $valores) {
			echo $valores."<br>";
		}
		
		$stmt=$conexion->prepare($consulta);
		$stmt->bindParam(':NOMBRE',$proyecto["NOMBRE"]);
		$stmt->bindParam(':DESCRIPCION',$proyecto["DESCRIPCION"]);
		$stmt->bindParam(':FECHA_INICIO',$proyecto["FECHA_INICIO"]);
		$stmt->bindParam(':FECHA_FINAL',$proyecto["FECHA_FINAL"]);
		$stmt->bindParam(':VALORACION',$proyecto["VALORACION"]);
		$stmt->bindParam(':NUMPLAZOS',$proyecto["NUMPLAZOS"]);
		$stmt->bindParam(':ESTADO',$proyecto["ESTADO"]);
		$stmt->bindParam(':PERMISO',$proyecto["PERMISO"]);
		
		$stmt->execute();
		return true;
	} catch(PDOException $e) {
		return false;
		// $_SESSION['excepcion'] = $e->GetMessage();
		// header("Location: excepcion.php");
	}
}

function consultarProyecto($conexion,$nombre) {
	$consulta= "SELECT COUNT(*)AS TOTAL "
				."FROM PROYECTO "
				."WHERE NOMBRE=:nombre";
	$stmt = $conexion->prepare($consulta);
	$stmt -> bindParam(":nombre", $nombre);
	$stmt -> execute();
	return $stmt->fetchColumn();

}