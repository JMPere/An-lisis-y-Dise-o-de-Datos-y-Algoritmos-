<?php
  /*
     * #===========================================================#
     * #	Este fichero contiene las funciones de gestión
     * #	de proyecto de la capa de acceso a datos
     * #==========================================================#
     */

    
     
 function alta_Proyecto($conexion,$proyecto) {
	
	if (!isset($_SESSION["login"])) {
	Header("Location:login.php");
	} 
	$usuario = $_SESSION["login"];
	
	$fechaInicio = date('d/m/Y', strtotime($proyecto["FECHA_INICIO"]));
	$fechaFinal = date('d/m/Y', strtotime($proyecto["FECHA_FINAL"]));
	
	try {
		/*$consulta = "INSERT INTO PROYECTO(NOMBRE, DESCRIPCION, FECHA_INICIO, FECHA_FINAL,VALORACION,DURACION,NUMPLAZOS,ESTADO,PERMISO,OID_CLIENTE,OID_EMPLEADO)
					VALUES(':NOMBRE' , ':DESCRIPCION' , DATE ':FECHA_INICIO' , DATE ':FECHA_FINAL' , :VALORACION ,
		 :DURACION , :NUMPLAZOS , :ESTADO , ':PERMISO' ,5,1)";*/
		 
		 $consulta = "CALL INSERTAR_PROYECTO(:NOMBRE,:DESCRIPCION, :FECHA_INICIO, :FECHA_FINAL, :VALORACION, :DURACION, :NUMPLAZOS,:ESTADO, :PERMISO, :oid)";

		
		$stmt=$conexion->prepare($consulta);
		$stmt->bindParam(':NOMBRE',$proyecto["NOMBRE"]);
		$stmt->bindParam(':DESCRIPCION',$proyecto["DESCRIPCION"]);
		$stmt->bindParam(':FECHA_INICIO',$fechaInicio);
		$stmt->bindParam(':FECHA_FINAL',$fechaFinal);
		$stmt->bindParam(':VALORACION',$proyecto["VALORACION"]);
		$stmt->bindParam(':DURACION',$proyecto["DURACION"]);
		$stmt->bindParam(':ESTADO',$proyecto["ESTADO"]);
		$stmt->bindParam(':NUMPLAZOS',$proyecto["NUMPLAZOS"]);
		$stmt->bindParam(':PERMISO',$proyecto["PERMISO"]);
		$stmt->bindParam(':oid',$usuario["OID_USUARIO"]);

		
	
		$stmt->execute();	
		return true;

	} catch(PDOException $e) {
		
		return false;
		// $_SESSION['excepcion'] = $e->GetMessage();
		//Header("Location: excepcion.php");
	}
}

function consultarUnProyecto($conexion, $oid_pro) {
	$consulta = "SELECT * FROM PROYECTO WHERE (PROYECTO.OID_PROYECTO=:oid)";
	$stmt = $conexion -> prepare($consulta);
	$stmt -> bindParam(":oid", $oid_pro);
	$stmt->execute();
	return $stmt->fetch();
}

function consultarTodosProyectos($conexion) {
	$usuario = $_SESSION["login"];
	$consulta = "SELECT * FROM PROYECTO WHERE (PROYECTO.OID_USUARIO=:oid) ORDER BY NOMBRE";
	$stmt = $conexion -> prepare($consulta);
	$stmt -> bindParam(":oid", $usuario['OID_USUARIO']);
	$stmt->execute();
	return $stmt;
}

/*
 function quitar_mueble($conexion,$OidMueble) {
 try {
 $stmt=$conexion->prepare('CALL QUITAR_LIBRO(:OidLibro)');
 $stmt->bindParam(':OidLibro',$OidLibro);
 $stmt->execute();
 return "";
 } catch(PDOException $e) {
 return $e->getMessage();
 }
 }

 function modificar_mueble($conexion,$OidMueble,$nombreMueble) {
 try {
 $stmt=$conexion->prepare('CALL MODIFICAR_TITULO(:OidLibro,:TituloLibro)');
 $stmt->bindParam(':OidLibro',$OidLibro);
 $stmt->bindParam(':TituloLibro',$TituloLibro);
 $stmt->execute();
 return "";
 } catch(PDOException $e) {
 return $e->getMessage();
 }
 }*/
?>
