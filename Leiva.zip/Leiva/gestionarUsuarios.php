<?php
  /*
     * #===========================================================#
     * #	Este fichero contiene las funciones de gestión
     * #	de usuarios de la capa de acceso a datos
     * #==========================================================#
     */

 function alta_usuario($conexion,$usuario) {
	$fechaNacimiento = date('d/m/Y', strtotime($usuario["FECHA_NACIMIENTO"]));
	
	try {
		$consulta = "CALL INSERTAR_CLIENTE(:DNI, :NOMBRE, :NICKNAME, :APELLIDOS, :CORREO, :FECHA_NACIMIENTO, :CONTRASEÑA, :DIRECCION)";
		$stmt=$conexion->prepare($consulta);
		$stmt->bindParam(':DNI',$usuario["DNI"]);
		$stmt->bindParam(':NOMBRE',$usuario["NOMBRE"]);
		$stmt->bindParam(':NICKNAME',$usuario["NICKNAME"]);
		$stmt->bindParam(':APELLIDOS',$usuario["APELLIDOS"]);
		$stmt->bindParam(':CORREO',$usuario["CORREO"]);
		$stmt->bindParam(':FECHA_NACIMIENTO',$fechaNacimiento);
		$stmt->bindParam(':CONTRASEÑA',$usuario["CONTRASEÑA"]);
		$stmt->bindParam(':DIRECCION',$usuario["DIRECCION"]);
		$stmt->execute();
		return true;
	} catch(PDOException $e) {
		return false;
		// $_SESSION['excepcion'] = $e->GetMessage();
		// header("Location: excepcion.php");
	}
}

function consultarUsuario($conexion,$email,$pass) {
	$consulta= "SELECT COUNT(*)AS TOTAL "
				."FROM CLIENTE "
				."WHERE NICKNAME=:nombre AND CONTRASEÑA=:pass";
	$stmt = $conexion->prepare($consulta);
	$stmt -> bindParam(":nombre", $email);
	$stmt -> bindParam(":pass", $pass);
	$stmt -> execute();
	return $stmt->fetchColumn();

}


