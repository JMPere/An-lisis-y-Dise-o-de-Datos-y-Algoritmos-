<?php
  /*
     * #===========================================================#
     * #	Este fichero contiene las funciones de gestión
     * #	de usuarios de la capa de acceso a datos
     * #==========================================================#
     */

 function alta_usuario($conexion,$usuario) {
	$fechaNacimiento = date('d/m/Y', strtotime($usuario["FECHA_NACIMIENTO"]));
	
	try {
		$consulta = "CALL INSERTAR_USUARIO(:DNI, :NICKNAME, :NOMBRE, :APELLIDOS, :CORREO, :FECHA_NACIMIENTO, :CONTRASEÑA, :DIRECCION, 'N')";
		$stmt=$conexion->prepare($consulta);
		$stmt->bindParam(':DNI',$usuario["DNI"]);
		$stmt->bindParam(':NOMBRE',$usuario["NOMBRE"]);
		$stmt->bindParam(':NICKNAME',$usuario["NICKNAME"]);
		$stmt->bindParam(':APELLIDOS',$usuario["APELLIDOS"]);
		$stmt->bindParam(':CORREO',$usuario["CORREO"]);
		$stmt->bindParam(':FECHA_NACIMIENTO',$fechaNacimiento);
		$stmt->bindParam(':CONTRASEÑA',$usuario["CONTRASEÑA"]);
		$stmt->bindParam(':DIRECCION',$usuario["DIRECCION"]);
		$stmt->execute();
		return true;
	} catch(PDOException $e) {
		return false;
		// $_SESSION['excepcion'] = $e->GetMessage();
		// header("Location: excepcion.php");
	}
}

function consultarUsuario($conexion,$email,$pass) {
	$consulta= "SELECT * "
				."FROM USUARIO "
				."WHERE NICKNAME=:nombre AND CONTRASEÑA=:pass";
	$stmt = $conexion->prepare($consulta);
	$stmt -> bindParam(":nombre", $email);
	$stmt -> bindParam(":pass", $pass);
	$stmt -> execute();
	return $stmt -> fetch();

}

function modificarUsuario($conexion,$oid, $nombre, $apellidos, $direccion, $nickname, $contraseña) {
	try {
		$consulta = "CALL MODIFICAR_USUARIO(:oid, :nombre, :ape, :dire, :nick, :con)";
		$stmt=$conexion->prepare($consulta);
		$stmt->bindParam(':oid',$oid);
		$stmt->bindParam(':nombre',$nombre);
		$stmt->bindParam(':ape',$apellidos);
		$stmt->bindParam(':dire',$direccion);
		$stmt->bindParam(':nick',$nickname);
		$stmt->bindParam(':con',$contraseña);
		$stmt->execute();
		return "";
	} catch(PDOException $e) {
		return $e->getMessage();
    }
}

function consultarTodosUsuarios($conexion) {
	$consulta = "SELECT * FROM USUARIO";
    return $conexion->query($consulta);
}

function modificarPermisoUsuario($conexion,$oid, $permiso) {
	try {
		$consulta = "CALL MODIFICARPERMISO_USUARIO(:oid, :permiso)";
		$stmt=$conexion->prepare($consulta);
		$stmt->bindParam(':oid',$oid);
		$stmt->bindParam(':permiso',$permiso);
		$stmt->execute();
		return "";
	} catch(PDOException $e) {
		return $e->getMessage();
    }
}

