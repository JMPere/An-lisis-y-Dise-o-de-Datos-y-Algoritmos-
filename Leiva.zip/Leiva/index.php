<?php
session_start();

require_once ("gestionBD.php");
require_once ("gestionarMuebles.php");

if (!isset($_SESSION["login"])) {
	Header("Location:login.php");
}
if (isset($_POST["OID_MUEBLE"])) {
	$_SESSION["OID_MUEBLE"] = $_POST["OID_MUEBLE"];
	Header("Location:vistaMueble.php");
}

$conexion = crearConexionBD();
$totalMuebles = consultarTodosMuebles($conexion);
$conexion = cerrarConexionBD($conexion);
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:400,600" />
    <link rel="stylesheet" href="css2/all.min.css" />
    <link rel="stylesheet" href="css2/bootstrap.min.css" />
    <link rel="stylesheet" href="css/main2.css" />
    <link rel="stylesheet" href="css/navbarindex.css" type="text/css">
    <link rel="stylesheet" href="css2/templatemo-style.css" />
    <title>Mobiliaria Leiva - Inicio</title>
 
  </head>
  <body>
  	
  	

  	
    <!-- Inicio -->
    <section id="tmWelcome" class="parallax-window" data-parallax="scroll" data-image-src="img/mini-profile-bg-01.jpg">
    	
      <div class="container-fluid tm-brand-container-outer">
        <div class="row">
        	
          <div class="col-12">            <?php
				include_once 'cabecera.php';
			?>

            <!-- Logo Area -->
            <!-- Black transparent bg -->
            <div class="ml-auto mr-0 tm-bg-black-transparent text-white tm-brand-container-inner">
              <div class="tm-brand-container text-center">
              	
                <h1 class="tm-brand-name" style="letter-spacing: 3px;">Mobiliaria Leiva</h1>
                <p class="tm-brand-description mb-0"></p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="tm-bg-white-transparent tm-welcome-container">
        <div class="container-fluid">
          <div class="row h-100">
            <!-- Welcome Text -->
            <!-- White transparent bg -->
            <div class="col-md-7 tm-welcome-left-col">
              <div class="tm-welcome-left">
                <h2 class="tm-welcome-title">¿Quienes somos?</h2>
                <p class="pb-0">
                  Leiva es un almacen de muebles dedicado a la venta y construcción de muebles. Pondremos a tu disposición decenas de estilos diferentes así como un 
                  empleado para que puedas crear el mueble de tus sueños. ¡No dudes en visitarnos! </p>
              </div>
            </div>
            <!-- Brown bg -->
            <div class="col-md-5">
              <div class="tm-welcome-right">
                <p class="mb-0">
					<img src="images/leiva logo.png" style="width: 100%; padding-top: 40px">            </p>         
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- End Inicio -->

    <!-- Muebles -->
    <section id="tmPortfolio">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
          			<?php $index = 0;
		foreach($totalMuebles as $fila) { if($index < 3){
		?>
					<form method="post" action="index.php">
            <div class="tm-portfolio-item">
            <input id="OID_MUEBLE" name="OID_MUEBLE" type="hidden"
						value="<?php echo $fila["OID_MUEBLE"]; ?>"/>
              <div class="tm-portfolio-name text-white tm-bg-blue" style="padding-right: 70px" >
              	<?php $imagen = "imageMueble/" . $fila["IMAGEN"] . ".jpg"; ?>
                <input id="IMAGEN" type="image" src="<?php echo $imagen; ?>" alt="submit">
              </div>
              <div class="tm-portfolio-description" style="padding-left: 70px">
                <h3 class="tm-text-dark-gray">
               <input id="NOMBREMUEBLE" name="NOMBREMUEBLE" type="submit"
						value="<?php echo $fila["NOMBREMUEBLE"]; ?>"/>
                  <span class="tm-title-small">(<?php echo $fila["PRECIO"]; ?>€)</span>
                </h3>
                <p class="mb-0">
                 <?php echo $fila["DESCRIPCION"]; ?>
                </p>
              </div>
            </div></form>
		<?php $index++; } }?>
		          </div>
        </div>
      </div>
    </section>
    <!-- End portfolio section -->


	<!-- Accesos directos -->
	
	
	    <div id="tmContact" class="parallax-window" data-parallax="scroll" data-image-src="img/mini-profile-bg-02.jpg">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="tm-contact-items-container2" style="text-align: center">
              <div class="fondito">               
                <i class="fas fa-5x fa-briefcase tm-contact-item-icon2"></i>
                <p class="mb-0">
                  	<h2 style="background-color: white; border-radius: 20px;
	border: 0; padding: 4px"> <a style="color: 
                  	grey;" href="creaProyecto.php" > ¿Deseas crear tu propio proyecto? </a></h2><br />
                </p>
                <p class="mb-0" style="background-color: white; border-radius: 20px;
	border: 0; padding: 4px">
                  	No dudes en ponerte en contacto con nuestra tienda, te contactaremos inmediatamente.
                </p>
              </div>
              <div class="fondito">
                <i class="fas fa-5x fa-building tm-contact-item-icon2"></i>
                 <p class="mb-0" style="background-color: white; border-radius: 20px;
	border: 0; padding: 4px">
                  	No te olvides de echar un vistazo a nuestro catálogo y a las ultimas ofertas de los mejores muebles.
                </p><br /><br />
               <p class="mb-0">
                  	<h2 style="background-color: white; border-radius: 20px;
	border: 0; padding: 4px"> <a style="color: 
                  	grey;" href="catalogo.php" > ¡No te lo pierdas! </a></h2><br />
                </p>
               
              </div>
            </div>


	
	
	
	<!-- End Accesos directos -->

    <!-- Contact section -->

        <div class="row">
          <div class="col-12">
            <div class="tm-contact-items-container" style="text-align: center">
              <div class="tm-contact-item">               
 				                <p class="mb-0">
                  	Visita nuestra tienda
                </p><img href="https://goo.gl/maps/DweCYkNoSeQsW9ZVA" src="images/ubi.png" style="width: 40%; padding-top: 80px">
                <i class="fas fa-5x fa-briefcase tm-contact-item-icon"></i>

                <p class="mb-0">
                  	<a href="https://www.google.es/maps/place/Almacen+De+Muebles/@37.3726507,-5.9599294,20z/data=!4m5!3m4!1s0xd126eed723c6569:0x4c7767631e731ca3!8m2!3d37.372617!4d-5.960028" style="color: 
                  	black"> Maestro Falla nº5 41940 Sevilla</a>
                </p>
              </div>
              <div class="tm-contact-item">
 				                <p class="mb-0">
                  	Póngase en contacto con nuestros empleados
                </p><img src="images/tlf.png" style="width: 40%; padding-top: 80px">                
                <i class="fas fa-5x fa-building tm-contact-item-icon"></i>
                <p class="mb-0">
                  954636936
                </p>
              </div>

              <div class="tm-contact-item">
 				                <p class="mb-0">
                  	¿Tiene alguna duda?        
                  	La responderemos en 24h
                </p><img src="images/mail.png" style="width: 40%; padding-top: 80px">
                <i class="fas fa-5x fa-balance-scale tm-contact-item-icon"></i>
                <p class="mb-0">
                  leivamueble@gmail.com

                </p>
              </div>
            </div>
          </div>
        </div>

      
        <!-- row -->
        <div class="row">
          <footer class="col-12">
            <p class="text-center tm-copyright-text">
          </footer>
        </div>
      </div>
      <!-- container -->
    </div>
    <!-- section -->
    <script src="js/jquery.min.js"></script>
    <script src="js/parallax.min.js"></script>
    <script>
      function detectMsBrowser() {
        using_ms_browser =
          navigator.appName == "Microsoft Internet Explorer" ||
          (navigator.appName == "Netscape" &&
            navigator.appVersion.indexOf("Edge") > -1) ||
          (navigator.appName == "Netscape" &&
            navigator.appVersion.indexOf("Trident") > -1);

        if (using_ms_browser == true) {
          alert(
            "Please use Chrome or Firefox for the best browsing experience!"
          );
        }
      }
      function setBrandMarginTop() {
        var bottomContainerHeight = $(".tm-welcome-container").height();

        $(".tm-brand-container-outer").css({
          "margin-top": -bottomContainerHeight + "px"
        });
      }

      $(function() {
        setBrandMarginTop();
        detectMsBrowser();

        // Handle window resize event
        $(window).resize(function() {
          setBrandMarginTop();
        });
      });
    </script>
  </body>
</html>