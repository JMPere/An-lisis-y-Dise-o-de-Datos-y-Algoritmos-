<?php
session_start();

require_once ("gestionBD.php");
require_once ("gestionarMuebles.php");

if (!isset($_SESSION["login"])) {
	Header("Location:login.php");
}

$conexion = crearConexionBD();
$totalMuebles = consultarTodosMuebles($conexion);
$conexion = cerrarConexionBD($conexion);
?>

<!-- =======HTML======= -->

<!DOCTYPE html>
<html
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>Mobiliaria Leiva - Inicio</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
<link rel="stylesheet" href="css/main.css" media="screen"  type="text/css">
<link rel="stylesheet" href="css/navbar.css" media="screen" type="text/css">
<link rel="stylesheet" href="css/carousel2.css" media="screen" type="text/css">

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>

<body>
	<header>
		<div class="topnav" id ="myTopnav">
			<img class="logo" src="images/leiva logo pequeño 2.jpg" alt="LOGO" href="index.html" style=" width: ">
			<a href="about.php">Sobre nosotros</a>
			<a href="#news">Catalogo</a>
			<a href="misProyectos.php">Mis proyectos</a>
			<a href="index.php" class="active">Inicio</a>
			<a href="javascript:void(0);" class="icon" onclick="myFunction()"> <i class="fa fa-bars"></i> </a>
		</div>
	
		<script>
			function myFunction() {
				var x = document.getElementById("myTopnav");
				if (x.className === "topnav") {
					x.className += " responsive";
				} else {
					x.className = "topnav";
				}
			}
		</script>
	
	</header>

<div class="slidershow middle">

	<div class="slides">
		<input type="radio" name="r" id="r1" checked>
		<input type="radio" name="r" id="r2">
		<input type="radio" name="r" id="r3">
		<input type="radio" name="r" id="r4">
		<input type="radio" name="r" id="r5">
		<div class="slide s1">
			<img src="images/car1.png" alt="">
		</div>
		<div class="slide">
			<img src="images/car4.png" alt="">
		</div>
		<div class="slide">
			<img src="images/car1.png" alt="">
		</div>
		<div class="slide">
			<img src="images/car4.png" alt="">
		</div>
		<div class="slide">
			<img src="images/car1.png" alt="">
		</div>
	</div>

	<div class="navigation">
		<label for="r1" class="bar"></label>
		<label for="r2" class="bar"></label>
		<label for="r3" class="bar"></label>
		<label for="r4" class="bar"></label>
		<label for="r5" class="bar"></label>
	</div>
</div>

	<div class="mueblesDestacados">
		<h2>Nuestros Destacados</h2>
	

	<div class="muebles" style="width: 100%">
		<?php

		$index = 0;
		foreach($totalMuebles as $fila) {
		if($index < 3){
		?>
		<article class="mueble">
			<form method="post" action="gestionarMuebles.php">
				<div class="fila_mueble">
					<div class="datos_mueble">
						<input id="OID_MUEBLE" name="OID_MUEBLE" type="hidden"
						value="<?php echo $fila["OID_MUEBLE"]; ?>"/>
						<?php $imagen = "imageMueble/" . $fila["IMAGEN"] . ".jpg"; ?>
						<input id="IMAGEN" type="image" src="<?php echo $imagen; ?>" alt="submit">
						<br />
						<input id="NOMBREMUEBLE" name="NOMBREMUEBLE" type="submit"
						value="<?php echo $fila["NOMBREMUEBLE"]; ?>"/>

					</div>
				</div>
			</form>
		</article>
		<?php $index++;
			}
		?>
		<?php } ?>
	</div> </div>
	</body>
	</html>
