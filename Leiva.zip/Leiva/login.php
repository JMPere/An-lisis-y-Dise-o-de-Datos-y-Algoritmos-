<?php
session_start();

include_once ("gestionBD.php");
include_once ("gestionarUsuarios.php");

if (isset($_POST["nickname"])) {

	$nickname = $_POST["nickname"];
	$pass = $_POST["contraseña"];
	$conexion = crearConexionBD();
	$consulta = consultarUsuario($conexion, $nickname, $pass);
	$conexion = cerrarConexionBD($conexion);

	if ($consulta != 0) {
		$_SESSION["login"] = $consulta;
		Header("Location:index.php");
	} else
		$error = "error";
}
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>Mobiliaria Leiva - Mis Proyectos</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" type="text/css" media="screen" href="css/login2.css">

		<script src="main.js"></script>
	</head>
	<body>

		<div class="container">
			<h2>login</h2>
			<form id="altaUsuario" method="post" action="login.php" class="formularioCrear">
							<input id="nickname" class="email" name="nickname" type="text" placeholder="Nickname" maxlength="40" required/>
				<br/>
							<input type="password"  class="pwd" name="contraseña" id="contraseña" placeholder="Contraseña" minlength="8" required />
			<br/>			<a class="link" style="color: rgba(192,192,192,0.9)"> <?php
			if (isset($error)) {
				echo "<div class=\"error\">";
				echo "Error en la contraseña o no existe el usuario.";
				echo "</div>";
			}
			?></a>
			<br/><span><input type="submit" class="signin" value="INICIA SESIÓN"/></span>
		<!--	<br/><span><input type="button" class="register" value="REGISTRATE"/></span> -->
			</form>

			<a class="register">
				<span><a class="link register" href="registrarse.php"> REGISTRATE</a></span>
			</a>
			<a class="signin">
				<span>inicia sesión</span>
			</a>
			<h3>your registration is complete ! </h3>
			<h3>your sign in is complete !</h3>
			<div class="reg"></div>
			<div class="sig"></div>

		</div>
	</body>
</html>