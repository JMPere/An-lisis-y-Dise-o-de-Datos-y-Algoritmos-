<?php
	session_start();
  	
  	include_once("gestionBD.php");
 	include_once("gestionarUsuarios.php");
	
	
	if (isset($_POST["nickname"])) {
	
		$email = $_POST["nickname"];
		$pass = $_POST["contraseña"];
		$conexion = crearConexionBD();
		$consulta = consultarUsuario($conexion, $email, $pass);
		$conexion = cerrarConexionBD($conexion);
		
		if($consulta != 0){
			$_SESSION["login"] = $email;
			Header("Location:index.php");
		} else 
			$error = "error";
		}
	
	
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" media="screen" href="css/login.css">
  <title>Mobiliaria Leiva - Login</title>
</head>

<body>


<main>
	<?php if (isset($error)) {
		echo "<div class=\"error\">";
		echo "Error en la contraseña o no existe el usuario.";
		echo "</div>";
	}	
	?>
	
	<!-- The HTML login form -->
	<form action="login.php" method="post">
		<div><label for="nickname">Nickname: </label>
		<input type="text" name="nickname" id="nickname" /></div>
		<div><label for="contraseña">Contraseña: </label>
		<input type="password" name="contraseña" id="contraseña" /></div>
		<input type="submit" name="submit" value="submit" />
	</form>
		
	<p>¿No estás registrado? <a href="registrarse.php">¡Registrate!</a></p>
</main>

</body>
</html>

