<?php
session_start();

require_once ("gestionBD.php");
require_once ("gestionarProyectos.php");

if (!isset($_SESSION["login"])) {
	Header("Location:login.php");
}
if (isset($_POST["OID_PROYECTO"])) {
	$_SESSION["OID_PROYECTO"] = $_POST["OID_PROYECTO"];
	Header("Location:ProyectoIndv.php");
}
$usu = $_SESSION["login"];
$conexion = crearConexionBD();
$totalProyectos = consultarTodosProyectos($conexion);
$conexion = cerrarConexionBD($conexion);
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>Mobiliaria Leiva - Mis Proyectos</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" type="text/css" media="screen" href="css/main.css">
		<link rel="stylesheet" type="text/css" media="screen" href="css/navbar2.css">
		<script src="main.js"></script>
	</head>
	<header>

<?php
	include_once 'cabecera.php';
?>



		<script>
			function myFunction() {
				var x = document.getElementById("myTopnav");
				if (x.className === "topnav") {
					x.className += " responsive";
				} else {
					x.className = "topnav";
				}
			}
		</script>
	</header>
	<body>
		<div class="top">

			<li>
				<p>
					Mis Proyectos
				</p>
			</li>
			<li>
				<a class="boton" href="creaProyecto.php">Crear Proyecto</a>
			</li>

		</div>

		<div class="tabla">
			<table class="proyectos" style="width:98%">
				<tr>
					<th><img src="images/workProject.png"></th>
					<th>Nombre Proyecto</th>
					<th>Fecha Creación</th>
				</tr>
				<?php
				foreach($totalProyectos as $fila) {
				?>

				<tr>
					<td><img src="images/workProject.png"></td>
					
					<td>
						<form method="post" action="misProyectos.php">
						<input id="OID_PROYECTO" name="OID_PROYECTO" type="hidden"
						value="<?php echo $fila["OID_PROYECTO"]; ?>"/>
						<input id="nombre" name="nombre" type="hidden"
						value="<?php echo $fila["NOMBRE"]; ?>"/>
						<input class="linkLista" href="intermedioAProyecto.php" id="vistaProyecto" name="vistaProyecto" type="submit" value="<?php echo $fila["NOMBRE"]; ?>"/>
						</form>
						</td>
					<td><?php echo $fila["FECHA_INICIO"]; ?></td>
				</tr>
						<?php
						}
		?>

		</table>
		</div>


	</body>
</html>