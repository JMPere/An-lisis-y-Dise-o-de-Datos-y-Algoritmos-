<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Mobiliaria Leiva - Mis Proyectos</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="css/main.css">
    <link rel="stylesheet" type="text/css" media="screen" href="css/navbar.css">
    <script src="main.js"></script>
</head>
<header>
	<div class="topnav" id ="myTopnav">
		<img class="logo" src="images/leiva logo pequeño 2.jpg" alt="LOGO" href="index.html" style=" width: ">
		<a href="about.php">Sobre nosotros</a>
		<a href="#news">Catalogo</a>
		<a href="misProyectos.php" class="active">Mis proyectos</a>
		<a href="index.php" >Inicio</a>
		<a href="javascript:void(0);" class="icon" onclick="myFunction()"> <i class="fa fa-bars"></i> </a>
	</div>

	<script>
		function myFunction() {
			var x = document.getElementById("myTopnav");
			if (x.className === "topnav") {
				x.className += " responsive";
			} else {
				x.className = "topnav";
			}
		}
	</script>

</header>
<body>
    <div class="top">
        
              <li><p>Mis Proyectos</p></li>
              <li><a class="boton" href="creaProyecto.php">Crear Proyecto</a></li>
        
    </div>

    <div class="tabla">
    <table class="proyectos" style="width:98%">
        <tr>
            <th><img src="images/workProject.png"></th>
            <th>Nombre Proyecto</th>
            <th>Fecha Creación</th>
        </tr>
        <tr>
            <td><img src="images/workProject.png"></td>
            <td><a class="linkLista" href="ProyectoIndv.php">Puerta Rosita</a></td>
            <td>19/20/19</td>
        </tr>
        <tr>
            <td><img src="images/workProject.png"></td>
            <td><a class="linkLista" href="ProyectoIndv.html">Silla Moderna</a></td>
            <td>19/20/19</td>
        </tr>
        <tr>
            <td><img src="images/workProject.png"></td>
            <td><a class="linkLista" href="ProyectoIndv.html">Silla Moderna</a></td>
            <td>19/20/19</td>
        </tr>
        <tr>
            <td><img src="images/workProject.png"></td>
            <td><a class="linkLista" href="ProyectoIndv.html">Silla Moderna</a></td>
            <td>19/20/19</td>
        </tr>
        <tr>
            <td><img src="images/workProject.png"></td>    
            <td><a class="linkLista" href="ProyectoIndv.html">Silla Moderna</a></td>
            <td>19/20/19</td>
        </tr>
        <tr>
            <td><img src="images/workProject.png"></td>
            <td><a class="linkLista" href="ProyectoIndv.html">Silla Moderna</a></td>
            <td>19/20/19</td>
        </tr>
    </table>
    </div>
</body>
</html>