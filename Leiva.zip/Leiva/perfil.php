<?php
session_start();

require_once ("gestionBD.php");
require_once ("gestionarUsuarios.php");

if (isset($_SESSION["login"])) {
	$datos = $_SESSION["login"];

} else {
	Header("Location:login.php");
}
$_SESSION['cambioUsuario'] = $datos;

// Si hay errores de validación, hay que mostrarlos y marcar los campos
if (isset($_SESSION["errores"]))
	$errores = $_SESSION["errores"];
unset($_SESSION["errores"]);
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>Mobiliaria Leiva - Mis Proyectos</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" type="text/css" media="screen" href="css/navbar2.css">
		<link rel="stylesheet" type="text/css" media="screen" href="css/creaProy.css">
		<script src="main.js"></script>
	</head>

		<?php
			include_once 'cabecera.php';
		?>

	<body>
		
		<div class="parametros">

			<form action="validacion_actualizar_usuario.php" method="post">
				<a class="btn" href="logout.php">Cerrar Sesión</a>
				<?php if($datos['PERMISO']=='Y'){
				
				 ?>
				<a class="btn" href="administrador.php">Funciones Administrador</a>
				<?php }
				
				 ?>
				<h2>Editar Perfil</h2>
				<div class="large-group">
					<div class="small-group">
						<label for="nom">Nombre</label>
						<input type="text" for="nom" name="nombre" id="nombre" value="<?php echo $datos['NOMBRE']; ?>"/>
					</div>

					<div class="small-group">
						<label for="apellidos">Apellidos: </label>
						<input type="text" name="apellidos" id="apellidos"  value="<?php echo $datos['APELLIDOS']; ?>"/>
					</div>
					<div class="small-group">
						<label for="direccion">Direccion: </label>
						<input type="text" name="direccion" id="direccion"  value="<?php echo $datos['DIRECCION']; ?>"/>
					</div>

					<div class="small-group">
						<label for="nickname">Nickname: </label>
						<input type="text" name="nickname" id="nickname" value="<?php echo $datos['NICKNAME']; ?>" />
					</div>

					<div class="small-group">
						<label for="antContra">Antigua Contraseña: </label>
						<input type="password" name="antContra" id="antContra"/>
					</div>

					<div class="small-group">
						<label for="newContra">Nueva Contraseña: </label>
						<input type="password" name="newContra" value="" id="newContra"/>
					</div>
					<input type="hidden" name="oid" id="oid" value="<?php echo $datos['OID_USUARIO']; ?>"/>

					<input id="submit" class="btn" value="Guardar Cambios" type="submit" name="submit"/>

				</div>
			</form>
		</div>
		<?php

		if (isset($errores) && count($errores) > 0) {
			echo "
<div id=\"div_errores\" class=\"error\">";
			echo "<h4> Errores en el formulario:</h4>";
			foreach ($errores as $error)
				echo $error;
			echo "</div>";
		}
		?>
	</body>
</html>

