<?php
session_start();

// Si no existen datos del formulario en la sesión, se crea una entrada con valores por defecto
if (!isset($_SESSION['formulario'])) {
	$formulario['NICKNAME'] = "";
	$formulario['DNI'] = "";
	$formulario['CONTRASEÑA'] = "";
	$formulario['NOMBRE'] = "";
	$formulario['APELLIDOS'] = "";
	$formulario['FECHA_NACIMIENTO'] = "";
	$formulario['CORREO'] = "";
	$formulario['DIRECCION'] = "";

	$_SESSION['formulario'] = $formulario;
}
// Si ya existían valores, los cogemos para inicializar el formulario
else
	$formulario = $_SESSION['formulario'];

// Si hay errores de validación, hay que mostrarlos y marcar los campos 
if (isset($_SESSION["errores"]))
	$errores = $_SESSION["errores"];
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>Mobiliaria Leiva - Registro</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" type="text/css" media="screen" href="css/registro.css">
		<script src="main.js"></script>

	</head>
	<body>
	<?php

		if (isset($errores) && count($errores) > 0) {
			echo "<div id=\"div_errores\" class=\"error\">";
			echo "<h4> Errores en el formulario:</h4>";
			foreach ($errores as $error)
				echo $error;
			echo "</div>";
		}
		?>
		<div class="container">
			<h2>resgistro</h2>
			<form id="altaUsuario" method="get" action="validacion_alta_usuario.php" class="formularioCrear" novalidate>
				<input id="NOMBRE" placeholder="Nombre" name="NOMBRE" type="text" maxlength="25" value="<?php echo $formulario['NOMBRE']; ?>" required/>
				<br/>
				<input id="APELLIDOS" placeholder="Apellidos" name="APELLIDOS" type="text" maxlength="40" value="<?php echo $formulario['APELLIDOS']; ?>" required/>
				<br/>
				<input id="DNI" name="DNI" type="text" placeholder="DNI" pattern="^[0-9]{8}[A-Z]" value="<?php echo $formulario['DNI']; ?>" title="Ocho dígitos seguidos de una letra mayúscula" required>
				<br/>
				<input type="date" id="FECHA_NACIMIENTO" placeholder="Fecha Nacimiento" name="FECHA_NACIMIENTO" value="<?php echo $formulario['FECHA_NACIMIENTO']; ?>" />
				<br/>
				<input id="NICKNAME" name="NICKNAME" placeholder="Nickname" type="text" maxlength="15" value="<?php echo $formulario['NICKNAME']; ?>"  required/>
				<br/>
				<input type="password" name="CONTRASEÑA" id="CONTRASEÑA" placeholder="Contraseña (Mínimo 8 caracteres)" minlength="8" required />
				<br/>
				<input type="password" name="Confirmar_Contraseña" id="pass" placeholder="Confirmar Contraseña" minlength="8"  required />
				<br />
				<input id="CORREO" name="CORREO"  type="email" value="<?php echo $formulario['CORREO']; ?>" placeholder="Correo" required/>
				<br/>
				<input id="DIRECCION"  placeholder="Dirección" name="DIRECCION" type="text" maxlength="80" value="<?php echo $formulario['DIRECCION']; ?>" required/>
				<br/>
				<a class="link" style="color: rgba(192,192,192,0.9)"> <?php
				if (isset($error)) {
					echo "<div class=\"error\">";
					echo "Error introduciendo los datos";
					echo "</div>";
				}
				?></a>
				<br/>
				<span>
					<input type="submit" class="signin" value="REGISTRATE"/>
				</span>
				<!--	<br/><span><input type="button" class="register" value="REGISTRATE"/></span> -->
			</form>

		</div>
	</body>
</html>

