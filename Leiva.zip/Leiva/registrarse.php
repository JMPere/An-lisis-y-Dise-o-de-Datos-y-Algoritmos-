<?php
session_start();

// Si no existen datos del formulario en la sesión, se crea una entrada con valores por defecto
if (!isset($_SESSION['formulario'])) {
	$formulario['NICKNAME'] = "";
	$formulario['DNI'] = "";
	$formulario['CONTRASEÑA'] = "";
	$formulario['NOMBRE'] = "";
	$formulario['APELLIDOS'] = "";
	$formulario['FECHA_NACIMIENTO'] = "";
	$formulario['CORREO'] = "";
	$formulario['DIRECCION'] = "";

	$_SESSION['formulario'] = $formulario;
}
// Si ya existían valores, los cogemos para inicializar el formulario
else
	$formulario = $_SESSION['formulario'];

// Si hay errores de validación, hay que mostrarlos y marcar los campos (El estilo viene dado y ya se explicará)
if (isset($_SESSION["errores"]))
	$errores = $_SESSION["errores"];
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>Mobiliaria Leiva - Registro</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" type="text/css" media="screen" href="css/login.css">
		<link rel="stylesheet" type="text/css" media="screen" href="css/main.css">
		<script src="main.js"></script>

	</head>
	<body>

		<?php

		if (isset($errores) && count($errores) > 0) {
			echo "<div id=\"div_errores\" class=\"error\">";
			echo "<h4> Errores en el formulario:</h4>";
			foreach ($errores as $error)
				echo $error;
			echo "</div>";
		}
		?>

		<p class="cabeceraForm"><img  src="images/leivaLogoPequeño.png" alt="LOGO" width=100px><b><ins>Regístrate</ins></b></p>

		<form id="altaUsuario" method="get" action="validacion_alta_usuario.php" class="formularioCrear" novalidate>
		<fieldset class="fondoCrear">
		<table class="tablaLogin" cellpadding="3">
		<tr>
		<td> Nombre: </td> <td><input id="NOMBRE" name="NOMBRE" type="text" maxlength="25" value="<?php echo $formulario['NOMBRE']; ?>" required/></td>
		</tr>
		<tr>
		<td> Apellidos: </td> <td><input id="APELLIDOS" name="APELLIDOS" type="text" maxlength="40" value="<?php echo $formulario['APELLIDOS']; ?>" required/></td>
		</tr>
		<tr>
		<td>DNI: </td><td><input id="DNI" name="DNI" type="text" placeholder="12345678X" pattern="^[0-9]{8}[A-Z]" value="<?php echo $formulario['DNI']; ?>" title="Ocho dígitos seguidos de una letra mayúscula" required></td>
		</tr>
		<tr>
		<td>Fecha de Nacimiento:</td><td> <input type="date" id="FECHA_NACIMIENTO" name="FECHA_NACIMIENTO" value="<?php echo $formulario['FECHA_NACIMIENTO']; ?>" />  <!--<img src="images/calendario.png" width="20px"></td>-->
		</tr>
		<tr>
		<td>Nombre de usuario: </td><td><input id="NICKNAME" name="NICKNAME" type="text" maxlength="15" value="<?php echo $formulario['NICKNAME']; ?>"  required/></td>
		</tr>
		<tr>
		<td>Contraseña: </td><td><input type="password" name="CONTRASEÑA" id="CONTRASEÑA" placeholder="Mínimo 8 caracteres" minlength="8" required /></td>
		</tr>
		<tr>
		<td>Confirmar Contraseña: </td><td><input type="password" name="Confirmar_Contraseña" id="pass" placeholder="Mínimo 8 caracteres" minlength="8"  required /></td>
		</tr>
		<tr>
		<td>Correo Electrónico:</td><td>  <input id="CORREO" name="CORREO"  type="email" value="<?php echo $formulario['CORREO']; ?>" placeholder="usuario@dominio.extension" required/></td>
		</tr>
		<tr>
		<td>Dirección: </td><td>   <input id="DIRECCION" name="DIRECCION" type="text" maxlength="80" value="<?php echo $formulario['DIRECCION']; ?>" required/></td>
		</tr>
		</table>
		</fieldset>
		<div  class="botonCrear" >
		<input type="submit" value="Enviar"/>
		</div>
		</form>
	</body>
</html>

