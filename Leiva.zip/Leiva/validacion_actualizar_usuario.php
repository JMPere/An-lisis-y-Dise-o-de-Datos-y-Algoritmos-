<?php
session_start();
// Comprobar que hemos llegado a esta página porque se ha rellenado el formulario
if (isset($_SESSION["cambioUsuario"])) {
	// Recogemos los datos del formulario
	$datito = $_SESSION["cambioUsuario"];
	$antiguaContra = $datito['CONTRASEÑA'];
	$cambio["NOMBRE"] = $_REQUEST["nombre"];
	$cambio["NICKNAME"] = $_REQUEST["nickname"];
	$cambio["APELLIDOS"] = $_REQUEST["apellidos"];
	$cambio["CONTRASEÑA"] = $_REQUEST["antContra"];
	if ($_REQUEST["newContra"] == '') {
		$cambio["NUEVA_CONTRASEÑA"] = $_REQUEST["antContra"];
	} else {
		$cambio["NUEVA_CONTRASEÑA"] = $_REQUEST["newContra"];

	}

	$cambio["DIRECCION"] = $_REQUEST["direccion"];
	$cambio["OID_USUARIO"] = $_REQUEST["oid"];

} else// En caso contrario, vamos al formulario
	Header("Location: perfil.php");

$_SESSION["cambioUsuario"] = $cambio;

if (!isset($_SESSION["login"])) {
	Header("Location:login.php");
}

$errores = validarDatosACambiar($cambio, $antiguaContra);
if (count($errores) > 0) {
	$_SESSION["errores"] = $errores;
	Header('Location: perfil.php');
} else
	Header('Location: accion_actualizar_usuario.php');

function validarDatosACambiar($datos, $antiguaContra) {

	// Validación del Nombre
	if ($datos["NOMBRE"] == "") {
		$errores[] = "<p>El nombre no puede estar vacío</p>";
	}
	// Validación del APELLIDOS
	if ($datos["APELLIDOS"] == "")
		$errores[] = "<p>Los apellidos no puede estar vacío</p>";

	//Validación de NICKNAME
	if ($datos['NICKNAME'] == '') {
		$errores[] = "<p>El nickname no puede estar vacío</p>";
	}

	// Validación de la contraseña
	if ($datos['CONTRASEÑA'] == '') {
		$errores[] = "<p>Debe rellenar la contraseña</p>";

	}
	if ($datos["CONTRASEÑA"] != $antiguaContra) {
		$errores[] = "<p>La contraseña es incorrecta</p>";
	}

	// Validación del DIRECCION
	if ($datos["DIRECCION"] == "")
		$errores[] = "<p>La direccion no puede estar vacío</p>";

	return $errores;
}
?>
