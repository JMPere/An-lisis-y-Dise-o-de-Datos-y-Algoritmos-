<?php
	session_start();

	// Comprobar que hemos llegado a esta página porque se ha rellenado el formulario
	if (isset($_SESSION["formulario"])) {
		// Recogemos los datos del formulario
		
	}
	else // En caso contrario, vamos al formulario
		Header("Location: registrarse.php");


?>