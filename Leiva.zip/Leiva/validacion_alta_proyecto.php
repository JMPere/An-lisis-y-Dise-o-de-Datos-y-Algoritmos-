<?php
	session_start();

	// Comprobar que hemos llegado a esta página porque se ha rellenado el formulario
	if (isset($_SESSION["proyecto"])) {
		// Recogemos los datos del formulario	
		$nuevoProyecto["NOMBRE"] = $_REQUEST["nom"];
		$nuevoProyecto["DESCRIPCION"] = $_REQUEST["Descripcion"];
		$nuevoProyecto["FECHA_INICIO"] = date("d-m-Y");
		$nuevoProyecto["FECHA_FINAL"] = date("d-m-Y",strtotime(date("d-m-Y")."+ 1 year"));
		$nuevoProyecto["VALORACION"] = "0";
		$nuevoProyecto["DURACION"] = "3";
		$nuevoProyecto["ESTADO"] = "3";
		$nuevoProyecto["PERMISO"] = "Y";
		
		/*foreach ($nuevoProyecto as $valores) {
			echo $valores."<br>";
		}*/
		
	}
	else // En caso contrario, vamos al formulario
		Header("Location: creaProyecto.php");
	
	$_SESSION["proyecto"]=$nuevoProyecto;
	
	$errores=validarDatosProyecto($nuevoProyecto);
	if (count($errores)>0) {
		$_SESSION["errores"] = $errores;
		Header('Location: creaProyecto.php');
	} else
		Header('Location: accion_alta_proyecto.php');
	
	
	function validarDatosProyecto($nuevoProyecto){
		
		// Validación del Nombre			
		if($nuevoProyecto["NOMBRE"]=="") 
			$errores[] = "<p>El nombre no puede estar vacío</p>";
	
		// Validación de la DESCRIPCION			
		if($nuevoProyecto["DESCRIPCION"]=="") 
			$errores[] = "<p>La descripcion no puede estar vacío</p>";
		
		// Validación del FECHA_FINAL			
		if($nuevoProyecto["FECHA_FINAL"]<$nuevoUsuario["FECHA_INICIO"]) 
			$errores[] = "<p>La fecha final no puede ser menor que la de inicio</p>";
		
		// Validación del VALORACION			
		if($nuevoProyecto["VALORACION"]=="") 
			$errores[] = "<p>La valoracion no puede estar vacío</p>";
			
			// Validación del DURACION			
		if($nuevoProyecto["DURACION"]=="") 
			$errores[] = "<p>La duracion no puede estar vacío</p>";
			
			// Validación del ESTADO			
		if($nuevoProyecto["ESTADO"]=="") 
			$errores[] = "<p>El estado no puede estar vacío</p>";
		
		
	}

?>