<?php
	session_start();

	// Comprobar que hemos llegado a esta página porque se ha rellenado el formulario
	if (isset($_SESSION["formulario"])) {
		// Recogemos los datos del formulario
		$nuevoUsuario["DNI"] = $_REQUEST["DNI"];
		$nuevoUsuario["NOMBRE"] = $_REQUEST["NOMBRE"];
		$nuevoUsuario["NICKNAME"] = $_REQUEST["NICKNAME"];
		$nuevoUsuario["APELLIDOS"] = $_REQUEST["APELLIDOS"];
		$nuevoUsuario["CORREO"] = $_REQUEST["CORREO"];
		$nuevoUsuario["FECHA_NACIMIENTO"] = $_REQUEST["FECHA_NACIMIENTO"];
		$nuevoUsuario["CONTRASEÑA"] = $_REQUEST["CONTRASEÑA"];
		$nuevoUsuario["Confirmar_Contraseña"] = $_REQUEST["Confirmar_Contraseña"];
		$nuevoUsuario["DIRECCION"] = $_REQUEST["DIRECCION"];
	}
	else // En caso contrario, vamos al formulario
		Header("Location: registrarse.php");

	$_SESSION["formulario"] = $nuevoUsuario;

	$errores = validarDatosUsuario($nuevoUsuario);
	
	if (count($errores)>0) {
		$_SESSION["errores"] = $errores;
		Header('Location: registrarse.php');
	} else
		Header('Location: accion_alta_usuario.php');

	///////////////////////////////////////////////////////////
	// Validación en servidor del formulario de alta de usuario
	///////////////////////////////////////////////////////////
	function validarDatosUsuario($nuevoUsuario){
		
		// Validación del Nombre			
		if($nuevoUsuario["NOMBRE"]=="") 
			$errores[] = "<p>El nombre no puede estar vacío</p>";
	
		// Validación del APELLIDOS			
		if($nuevoUsuario["APELLIDOS"]=="") 
			$errores[] = "<p>Los apellidos no puede estar vacío</p>";
		
		// Validación del DNI
		if($nuevoUsuario["DNI"]=="") 
			$errores[] = "<p>El DNI no puede estar vacío</p>";
		else if(!preg_match("/^[0-9]{8}[A-Z]$/", $nuevoUsuario["DNI"])){
			$errores[] = "<p>El DNI debe contener 8 números y una letra mayúscula: " . $nuevoUsuario["DNI"]. "</p>";
		}
		
		//Validación de NICKNAME
		if($nuevoUsuario['NICKNAME'=='']){
			$errores[] = "<p>El nickname no puede estar vacío</p>";
		}
		
		// Validación de la contraseña
		if(!isset($nuevoUsuario["CONTRASEÑA"]) || strlen($nuevoUsuario["CONTRASEÑA"])<8){
			$errores [] = "<p>Contraseña no válida: debe tener al menos 8 caracteres</p>";
		}else if($nuevoUsuario["CONTRASEÑA"] != $nuevoUsuario["Confirmar_Contraseña"]){
			$errores[] = "<p>La confirmación de contraseña no coincide con la contraseña</p>";
		}
	
		return $errores;
		}
		// Validación del email
		if($nuevoUsuario["EMAIL"]==""){ 
			$errores[] = "<p>El email no puede estar vacío</p>";
		}else if(!filter_var($nuevoUsuario["EMAIL"], FILTER_VALIDATE_EMAIL)){
			$errores[] = $error . "<p>El email es incorrecto: " . $nuevoUsuario["EMAIL"]. "</p>";
		}
		
		// Validación del DIRECCION			
		if($nuevoUsuario["DIRECCION"]=="") 
			$errores[] = "<p>La direccion no puede estar vacío</p>";

?>

