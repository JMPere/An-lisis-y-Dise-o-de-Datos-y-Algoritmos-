<?php
	session_start();

	// Comprobar que hemos llegado a esta página porque se ha rellenado el formulario
	if (isset($_SESSION["muebleCatalogo"])) {
		// Recogemos los datos del formulario	
		$nuevoMuebleCatalogo["NOMBRE"] = $_POST["nom"];
		$nuevoMuebleCatalogo["DESCRIPCION"] = $_POST["Descripcion"];
		$nuevoMuebleCatalogo["PRECIO"] = $_POST["precio"];
		$nuevoMuebleCatalogo["IMAGEN"] = $_POST["imagen"];
		$nuevoMuebleCatalogo["STOCK"] = $_POST["stock"];	
	}
	else // En caso contrario, vamos al formulario
		Header("Location: gestionCatalogo.php");
	
	$_SESSION["muebleCatalogo"]=$nuevoMuebleCatalogo;
	
	$errores=validarDatosProyecto($nuevoMuebleCatalogo);
	if (count($errores)>0) {
		$_SESSION["errores"] = $errores;
		Header('Location: gestionCatalogo.php');
	} else
		Header('Location: accion_alta_catalogo.php');
	
	
	function validarDatosProyecto($nuevoMuebleCatalogo){
		
		// Validación del Nombre			
		if($nuevoMuebleCatalogo["NOMBRE"]=="") 
			$errores[] = "<p>El nombre no puede estar vacío</p>";
	
		// Validación de la DESCRIPCION			
		if($nuevoMuebleCatalogo["DESCRIPCION"]=="") 
			$errores[] = "<p>La descripcion no puede estar vacío</p>";
		
		// Validación del PRECIO			
		if($nuevoMuebleCatalogo["PRECIO"]<0 || $nuevoMuebleCatalogo["PRECIO"]=="") 
			$errores[] = "<p>El precio tiene que ser mayor de 0</p>";
		
		// Validación del VALORACION			
		if($nuevoMuebleCatalogo["STOCK"]<0 || $nuevoProyecto["STOCK"]=="") 
			$errores[] = "<p>La valoracion no puede estar vacío</p>";
			
			// Validación del IMAGEN			
		if($nuevoProyecto["IMAGEN"]=="") 
			$errores[] = "<p>La imagen no puede estar vacío</p>";
			
		
	}

?>