<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Detalles del producto</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="css/vistaMueble.css">
    <link rel="stylesheet" type="text/css" media="screen" href="css/main.css">
    <link rel="stylesheet" type="text/css" media="screen" href="css/navbar2.css">
    
    <link rel="stylesheet" type="text/css" media="screen" href="vistaMueble.css">
    <script src="main.js"></script>
</head>
    <body >
    <div class="vistaMueble">
         <?php
				include_once 'cabecera.php';
			?>
        <div class="espaciovista"></div>
        <!--OPCIONES DEL MUEBLE-->
        <div class= "gridProducto">
            <div class=fotomueble><img src="https://www.decosillas.com/fe-800x800-ffffff-data/productos/silla-thonet-roblemetal-new.jpg"width=80% ></img></div>

            <div class="infovista"><p><h1><ins>SILLA DO MACACO</h1></ins> </p>  <!--NOMBRE-->
                <table><td>
                    <tr> La descripcion de este mueble pos es una descripción asi to wapilla que me acabo de sacar de la manda la vd, para que engañarnos. Pero bueno, ya que estamos. ¿Qué le dice un porro a otro? <br/>
                         Yo no lo sé, pero ahora que lo has dicho entraba uno ajjaj, salu2
                    
                    </tr>
                    <td><br/></td>
                    <td><br/></td>
                    <tr><td> <form><i><ins>PRECIO:</ins></i> 35€/unidad  <br/><br/>  <i><ins>Cantidad:</ins></i>  <input type="number" placeholder="Cantidad" min="1" required value="1" ></td> </tr>
                    <td> <br/><input type="submit" value="Añadir al carrito"></td>
                    
                    
                </td></table>
                
            </div>
        </div>

    </div>
    </div>
    </body>
</html>