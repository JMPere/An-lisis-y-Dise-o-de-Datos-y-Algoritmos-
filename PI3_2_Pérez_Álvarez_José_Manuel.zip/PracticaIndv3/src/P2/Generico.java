package P2;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

import us.lsi.lpsolve.solution.AlgoritmoPLI;
import us.lsi.lpsolve.solution.SolutionPLI;

public class Generico {

	public static void main(String[] args) {
		List<String> b= leerFichero("ficheros/generico.txt");
		
		SolutionPLI a = AlgoritmoPLI.getSolution(concatenarProblema(b));
		System.out.println("-------------------");	
		System.out.println("________");
		System.out.println(a.getGoal());
		for (int j = 0; j < a.getNumVar(); j++) {
			System.out.println(a.getName(j)+" = "+a.getSolution()[j]);
		}
		System.out.println("________");
	}
	
	private static List<String> leerFichero(String fichero) {
		List<String> res=null;
		try {
			 res = Files.readAllLines(Paths.get(fichero));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return res;
	}
	
	private static String funcionObjetivo(List<String> fichero) {
		
		String res="min: T;\n\n";
		String[] tareas = getTareas(fichero);

		for (int i = 0; i < getProcesadores(fichero); i++) {
			for (int j = 0; j < tareas.length; j++) {
				res+="+"+tareas[j]+"*x"+i+j;
			}
			res+="<=T;\n";
		}
		return res+"\n";
	}
	
	private static String Restricciones(List<String> fichero) {
		
		String res="";
		
		for (int i = 0; i < getTareas(fichero).length; i++) {
			for (int j = 0; j < getProcesadores(fichero); j++) {
				res+="+x"+j+i;
			}
			res+="=1;\n";
		}
		
		return res+"\n";
	}
	
	private static String declaraVariables(List<String> fichero) {
		String res="int T;\nbin ";
		for (int i = 0; i < getProcesadores(fichero); i++) {
			for (int j = 0; j < getTareas(fichero).length; j++) {
				res+=" x"+i+j;
			}
		}
		return res+";";
	}
	
	private static String concatenarProblema(List<String> fichero) {
		return funcionObjetivo(fichero)+Restricciones(fichero)+declaraVariables(fichero);
	}
	
	private static String[] getTareas(List<String> fichero) {
		return fichero.get(0).split(",");
	}
	
	private static Integer getProcesadores(List<String> fichero) {
		return Integer.parseInt(fichero.get(1).trim());
	}
	
}
