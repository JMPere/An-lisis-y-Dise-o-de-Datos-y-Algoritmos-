package P2;

import us.lsi.lpsolve.solution.AlgoritmoPLI;
import us.lsi.lpsolve.solution.SolutionPLI;

public class TestEspecifico {
	
	public static void main(String[] args) {
		SolutionPLI a = AlgoritmoPLI.getSolutionFromFile("./ficheros/Especifico.txt");
		System.out.println("-------------------");	
		System.out.println("________");
		System.out.println(a.getGoal());
		for (int j = 0; j < a.getNumVar(); j++) {
			System.out.println(a.getName(j)+" = "+a.getSolution()[j]);
		}
		System.out.println("________");
		

	}
	
}
