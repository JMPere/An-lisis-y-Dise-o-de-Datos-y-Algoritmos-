package P2;

public class TestGenetico {

	public static void main(String[] args) {
		Genetico g = new Genetico("./ficheros/generico.txt");
		
	}
	
}
