package P4;

public class Camino {
	private Monumento origen;
	private Monumento destino;
	private Double tiempo; //Tiempo asociado al camino, es decir, lo que tarda en recorrerlo

	public Camino(Monumento origen, Monumento destino, Double tiempo) {
		this.origen = origen;
		this.destino = destino;
		this.tiempo = tiempo;
	}
	public Camino(Monumento origen, Monumento destino ) {
		this.origen = origen;
		this.destino = destino;
		this.tiempo = null;
	}
	

	public Monumento getOrigen() {
		return origen;
	}

	public void setOrigen(Monumento origen) {
		this.origen = origen;
	}

	public Monumento getDestino() {
		return destino;
	}

	public void setDestino(Monumento destino) {
		this.destino = destino;
	}

	public Double getTiempo() {
		return tiempo;
	}

	public void setTiempo(Double tiempo) {
		this.tiempo = tiempo;
	}
	public static Camino create() {
		return new Camino(null,null,null);
	}
	public static Camino create(Monumento origen, Monumento destino) {
		return new Camino(origen,destino,null);
	}
	public static Camino create(Monumento origen, Monumento destino,String[] f) {
		return new Camino(origen,destino,Double.parseDouble(f[2]));
	}
//	public static Camino create(String[] linea) {
//		return new Camino(Monumento.create(linea[0]),Monumento.create(linea[1]),Double.parseDouble(linea[2]));
//	}
}
