package P4;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.jgrapht.Graph;
import org.jgrapht.alg.connectivity.ConnectivityInspector;
import org.jgrapht.graph.SimpleWeightedGraph;
import us.lsi.graphs.GraphsReader;

public class Ej4 {

	public static void main(String[] args) {
		
		Graph<Monumento, Camino> g=GraphsReader.newGraph("./ficheros/P4-Grafo1.txt", 
				Monumento::create, 
				Camino::create, 
				()->new SimpleWeightedGraph<Monumento, Camino>(
						Monumento::create, Camino::create),
				Camino::getTiempo);
		apartadoA(g);
		monumentosIniciales(g);
		
	}
	
	public static void apartadoA(Graph<Monumento, Camino> grafo) {
		
		ConnectivityInspector<Monumento, Camino> resG = new ConnectivityInspector<>(grafo);
		System.out.println("================================APARTADO A==================================\n");
		if(resG.isConnected()) {
			System.out.print("Est�n todos los sitios conectados entre s�? : S�.");
		}else {
			System.out.print("Est�n todos los sitios conectados entre s�? : No.");
		}
		System.out.println("Las listas conexas son= {");
		List<Set<Monumento>> Sets = resG.connectedSets();
			for (Set<Monumento> set : Sets) {
				System.out.println(set);
			}
			System.out.println("}");
	}
	
	public static void monumentosIniciales(Graph<Monumento,Camino> grafo) {
		Set<Monumento> vertices = grafo.vertexSet();
		List<Monumento> lista = vertices.stream().filter(x-> grafo.inDegreeOf(x)==0).collect(Collectors.toList());
		System.out.println("Lista de monumentos que se pueden visitar inicialmente sin haber visto otros: " + lista);
	}
	
	public static Monumento buscarVertice(Graph<Monumento, Camino> grafo, String nombre) {
		return grafo.vertexSet().stream().filter(x->x.getNombre().equals(nombre)).findFirst().get();
	}
	
}
