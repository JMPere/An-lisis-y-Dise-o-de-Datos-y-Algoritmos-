package P2;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;



public class Ej2 {
	
	public static void main(String[] args) {
		List<Integer> tareas = new ArrayList<>();	//Lista de Tareas
		tareas.add(5);		tareas.add(4);		tareas.add(6);		tareas.add(3);		tareas.add(2);
//		tareas.add(5);		tareas.add(3);		tareas.add(2);		tareas.add(9);		tareas.add(3);
//		tareas.add(10);		tareas.add(2);		tareas.add(1);		tareas.add(7);		tareas.add(6);
		
		Map<String, List<Integer>> asignacion = new HashMap<>();	//Asignacion de tareas por procesador
		
		List<String> proc = new ArrayList<>();		//Lista de Procesadores
		proc.add("p0");		proc.add("p1");		//proc.add("p2"); 	proc.add("p3");
		
		for (String string : proc) {			//inicializacion de listas de tareas por procesador
			asignacion.put(string, new ArrayList<>());
		}
		
		String procMenorTareas="";
		
		for(int i=0;i<tareas.size();i++) {				//Asignacion de tareas al procesador con menor tareas
			
			Integer contador=sumaLista(asignacion.get(proc.get(0)));
			
			for (int j = 0; j < proc.size(); j++) {		//Busqueda del procesador con menos tareas
				
				Integer sumalista=sumaLista(asignacion.get(proc.get(j)));
				if(sumalista<=contador) {
					contador=sumalista;
					procMenorTareas=proc.get(j);
					
				}
				
			}
			asignacion.get(procMenorTareas).add(tareas.get(i));
			System.out.println(asignacion+"\n");
			
		}
		
		//Muestra Resultados
		System.out.println("\nResultado final: "+asignacion+"\nNumTotalTareas: "+sumaLista(tareas));
		for (String p : proc) {
			
			System.out.println(p+": "+sumaLista(asignacion.get(p)));
			
		}
		
	}
	
	public	static Integer sumaLista(List<Integer> l) {		//Metodo auxiliar para sumar las tareas de una lista
		
		Integer res=0;
		
		for (int i = 0; i < l.size(); i++) {
			res=res+l.get(i);
		}
		
		return res;
		
	}
	
}
