package Ej2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import us.lsi.pd.AlgoritmoPD.Sp;
import us.lsi.pd.AlgoritmoPD.Tipo;
import us.lsi.pd.ProblemaPDR;

public class Ej2_PDR implements ProblemaPDR<List<Integer>, Integer, Ej2_PDR> {
	public static List<Integer> listaDatos;
	public static Integer totalSuma;
	private Integer index;
	private Integer acum;

	
	public static Ej2_PDR create(Integer index, Integer acum, List<Integer> lista, Integer n) {
		listaDatos= lista;
		totalSuma=n;
		return new Ej2_PDR(index, acum);
	}
	
	public Ej2_PDR(Integer index, Integer acum) {
		super();
		this.acum = acum;
		this.index = index;
	}

	@Override
	public Tipo getTipo() {
		return Tipo.Max;
	}

	@Override
	public int size() {
		return listaDatos.size() - index;
	}

	@Override
	public boolean esCasoBase() {
		return index == listaDatos.size();
	}

	@Override
	public Sp<Integer> getSolucionParcialCasoBase() {
		Sp<Integer> res = null;
		if (acum == totalSuma) {
			res = Sp.create(null, 0.);
		}
		return res;
	}

	@Override
	public Ej2_PDR getSubProblema(Integer a) {
		return new Ej2_PDR(index + 1, acum + (listaDatos.get(index) * a));
	}

	@Override
	public Sp<Integer> getSolucionParcialPorAlternativa(Integer a, Sp<Integer> s) {
		return Sp.create(a, s.propiedad + listaDatos.get(index)%2==0?1.:0.);
	}

	@Override
	public List<Integer> getAlternativas() {
		return Arrays.asList(0,1);
	}

	@Override
	public List<Integer> getSolucionReconstruidaCasoBase(Sp<Integer> sp) {
		return new ArrayList<Integer>();
	}

	@Override
	public List<Integer> getSolucionReconstruidaCasoRecursivo(Sp<Integer> sp, List<Integer> s) {
		List<Integer> res = new ArrayList<Integer>(s);
		if(sp.alternativa==1) {
			res.add(listaDatos.get(index));
		}
		return res;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((acum == null) ? 0 : acum.hashCode());
		result = prime * result + ((index == null) ? 0 : index.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Ej2_PDR other = (Ej2_PDR) obj;
		if (acum == null) {
			if (other.acum != null)
				return false;
		} else if (!acum.equals(other.acum))
			return false;
		if (index == null) {
			if (other.index != null)
				return false;
		} else if (!index.equals(other.index))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ejercicio2PD [index=" + index + ", acum=" + acum + "]";
	}

}
