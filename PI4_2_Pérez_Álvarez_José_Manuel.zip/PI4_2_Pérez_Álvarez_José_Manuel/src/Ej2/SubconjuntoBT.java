package Ej2;

import java.util.List;

public class SubconjuntoBT {

	private static List<Integer> lista;

	public static List<Integer> getLista() {
		return lista;
	}

	public static void setLista(List<Integer> lista) {
		SubconjuntoBT.lista = lista;
	}
	
	
	
}
