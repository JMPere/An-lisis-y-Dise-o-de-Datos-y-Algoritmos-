# lab7-OAuth
Laboratorio 7 de AISS sobre el uso de OAuth2 para acceder a recursos protegidos en las APIs de Google Drive y Spotify
