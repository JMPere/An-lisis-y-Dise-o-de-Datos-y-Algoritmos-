package aiss.api;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.core.Application;

import aiss.api.resources.PeliculasApiResource;
import aiss.api.resources.ReseñasApiResources;
import aiss.api.resources.VideosApiResource;

public class MoviedatabaissApplication extends Application {

	private Set<Object> singletons = new HashSet<Object>();
	private Set<Class<?>> classes = new HashSet<Class<?>>();

	public MoviedatabaissApplication() {
		singletons.add(PeliculasApiResource.getInstance());
		singletons.add(VideosApiResource.getInstance());
		singletons.add(ReseñasApiResources.getInstance());
	}

	public Set<Class<?>> getClasses() {
		return classes;
	}

	public Set<Object> getSingletons() {
		return singletons;
	}
}
