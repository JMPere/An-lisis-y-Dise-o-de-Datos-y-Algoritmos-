package aiss.api.resources;

import java.net.URI;
import java.util.Collection;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;

import org.jboss.resteasy.spi.BadRequestException;
import org.jboss.resteasy.spi.NotFoundException;

import aiss.model.Pelicula;
import aiss.model.Reseña;
import aiss.model.repository.MapMovidedatabaissRepository;
import aiss.model.repository.MoviedatabaissRepository;

@Path("/movies")
public class PeliculasApiResource {

	private static PeliculasApiResource _instance = null;
	MoviedatabaissRepository repository;

	private PeliculasApiResource() {
		repository = MapMovidedatabaissRepository.getInstance();

	}

	public static PeliculasApiResource getInstance() {
		if (_instance == null)
			_instance = new PeliculasApiResource();
		return _instance;
	}

	
	// Método que devuelve todas las peliculas
	@GET
	@Produces("application/json")
	public Collection<Pelicula> getAllMovies() {
		return repository.getAllMovies();
	}
	
	// Método que devuelve una pelicula con una determinada id
	@GET
	@Path("/{id}")
	@Produces("application/json")
	public Pelicula getMovieById(@PathParam("id") String id) {
		Pelicula pelicula = repository.getMovieById(id);
		if (pelicula == null) {
			throw new BadRequestException("La pelicula solicitado no existe.");
		}
		return pelicula;
	}
	
	// Método que devuelve todas las peliculas de un determinado título
	@GET
	@Path("/{title}")
	@Produces("application/json")
	public Collection<Pelicula> getMoviesByTitle(@QueryParam("title") String title) {
		Collection<Pelicula> res = repository.getMoviesByTitle(title);
		if (res == null) {
			throw new NotFoundException("No se encuentra ninguna película.");
		}
		return res;
	}
	
	// Método que añade una pelicula
	@POST
	@Consumes("application/json")
	@Produces("application/json")
	public Response addMovie(@Context UriInfo uriInfo, Pelicula pelicula) {
		if (pelicula.getId() == null || pelicula.getId() == "") {
			throw new BadRequestException("La pelicula no es válida");
		}
		repository.addMovie(pelicula);
		UriBuilder ub = uriInfo.getAbsolutePathBuilder().path(this.getClass(), "get");
		URI uri = ub.build(pelicula.getId());
		ResponseBuilder resp = Response.created(uri);
		resp.entity(pelicula);
		return resp.build();
	}

	// Método que actualiza una pelicula
	@PUT
	@Consumes("application/json")
	public Response updateMovie(Pelicula pelicula) {
		Pelicula oldpelicula = repository.getMovieById(pelicula.getId());
		if (oldpelicula == null) {
			throw new NotFoundException("La película con id="+ pelicula.getId() +" no fue encontrada");			
		}
		if (pelicula.getReviews()!=null) {
			throw new BadRequestException("Las reviews no son editables");

		}
		// Update name
		if (pelicula.getName()!=null)
			oldpelicula.setName(pelicula.getName());
		
		// Update description
		if (pelicula.getOverview()!=null)
			oldpelicula.setOverview(pelicula.getOverview());
		
		return Response.noContent().build();
	}

	// Método que elimina una pelicula
	@DELETE
	@Path("/{id}")
	@Consumes("application/json")
	public Response removeMovie(@PathParam("id") String id) {
		Pelicula movie = repository.getMovieById(id);
		if (movie == null) {
			throw new NotFoundException("La película con id="+ id +" no fue encontrada");			
		}
		else {
			repository.deleteMovie(id);
		}
		return Response.noContent().build();
	}
	
	// Método que añade una review a una pelicula
	@POST
	@Path("/{idMovie}/{idReview}")
	@Consumes("application/json")
	@Produces("application/json")
	public Response addReview(@Context UriInfo uriInfo, @PathParam("idMovie") String idMovie, @PathParam("idReview") String idReview) {
		Pelicula pelicula = repository.getMovieById(idMovie);
		Reseña review = repository.getReviewById(idReview);
		if (pelicula == null || idMovie == "" || idReview == "") {
			throw new BadRequestException("La review no es válida");
		}
		repository.addReview(idMovie, idReview);
		ResponseBuilder resp = Response.created(uriInfo.getAbsolutePath());
		resp.entity(review);   
		return resp.build();
	}

	// Método que elimina una review de una pelicula
	@DELETE
	@Path("/{idMovie}/{idReview}")
	@Consumes("application/json")
	public Response deleteReview(@PathParam("idMovie") String idMovie, @PathParam("idReview") String idReview) {
		if (idReview == null) {
			throw new NotFoundException("La review no fue encontrada");			
		}
		if (idMovie == null) {
			throw new NotFoundException("La pelicula no fue encontrada");			
		}
		else {
			repository.deleteReview(idMovie, idReview);
		}
		return Response.noContent().build();
	}
	
}
