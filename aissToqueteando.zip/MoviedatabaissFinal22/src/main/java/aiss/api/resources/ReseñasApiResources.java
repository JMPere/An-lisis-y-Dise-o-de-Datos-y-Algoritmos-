package aiss.api.resources;

import java.net.URI;
import java.util.Collection;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;

import org.jboss.resteasy.spi.BadRequestException;
import org.jboss.resteasy.spi.NotFoundException;

import aiss.model.Reseña;
import aiss.model.repository.MapMovidedatabaissRepository;
import aiss.model.repository.MoviedatabaissRepository;

@Path("/reviews")
public class ReseñasApiResources {

		public static ReseñasApiResources _instance = null;
		MoviedatabaissRepository repository;

		private ReseñasApiResources() {
			repository = MapMovidedatabaissRepository.getInstance();

		}

		public static ReseñasApiResources getInstance() {
			if (_instance == null)
				_instance = new ReseñasApiResources();
			return _instance;
		}

		// Método que devuelve todas las reseñas
		@GET
		@Produces("application/json")
		public Collection<Reseña> getAllReviews() {
			return repository.getAllReviews();
		}
		
		// Método que devuelve la review de la id determinada
		@GET
		@Path("/{idReview}")
		@Produces("application/json")
		public Reseña getReviewById(@PathParam("idReview") String idReview) {
			Reseña res = repository.getReviewById(idReview);
			if (res == null) {
				throw new NotFoundException("No se encuentra ninguna review.");
			}
			return res;
		}
		
		// Método que devuelve todas las reseñas del nombre de una determinada pelicula
		@GET
		@Path("/{titleMovie}")
		@Produces("application/json")
		public Collection<Reseña> getReviewsByMovie(@QueryParam("titleMovie") String titleMovie) {
			Collection<Reseña> res = repository.getReviewsByMovie(titleMovie);
			if (res == null) {
				throw new NotFoundException("No se encuentra ninguna review.");
			}
			return res;
		}	
		
		// Método que devuelve un vídeo con una determinada id
		@GET
		@Path("/{autor}")
		@Produces("application/json")
		public Collection<Reseña> getReviewByAutor(@PathParam("idReview") String idReview) {
			Collection<Reseña> reseñas = repository.getReviewsByAutor(idReview);
			if (reseñas == null) {
				throw new BadRequestException("La review solicitado no existe.");
			}
			return reseñas;
		}
			
		// Método que añade una review
		@POST
		@Consumes("application/json")
		@Produces("application/json")
		public Response addReview(@Context UriInfo uriInfo, Reseña reseña) {
			if (reseña.getId() == null || "".equals(reseña.getAutor()) || "".equals(reseña.getComentario()))
				throw new BadRequestException("The review must not be null");
			repository.addReview(reseña);
			UriBuilder ub = uriInfo.getAbsolutePathBuilder().path(this.getClass(), "get");
			URI uri = ub.build(reseña.getId());
			ResponseBuilder resp = Response.created(uri);
			resp.entity(reseña);			
			return resp.build();
		}
		
		// Método que actualiza una review
		@PUT
		@Consumes("application/json")
		public Response updateReview(Reseña reseña) {
			Reseña oldReview = repository.getReviewById(reseña.getId());
			if (oldReview == null) {
				throw new NotFoundException("The review with id="+ reseña.getId() +" was not found");			
			}		
			// Update autor
			if (reseña.getAutor()!=null) {
				oldReview.setAutor(reseña.getAutor());
			}
					
			// Update comentario
			if (reseña.getComentario()!=null) {
				oldReview.setComentario(reseña.getComentario());
			}
					
			return Response.noContent().build();
		}
		
		// Método que elimina una review
		@DELETE
		@Path("/{idReview}")
		public Response removeReview(@PathParam("idReview") String idReview) {
			Reseña toberemoved=repository.getReviewById(idReview);
			if (toberemoved == null)
				throw new NotFoundException("The review with id="+ idReview +" was not found");
			else
				repository.deleteReview(idReview);
			
			return Response.noContent().build();
		}

}
