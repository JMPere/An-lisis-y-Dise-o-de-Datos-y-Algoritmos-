package aiss.api.resources;

import java.net.URI;
import java.util.Collection;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;

import org.jboss.resteasy.spi.BadRequestException;
import org.jboss.resteasy.spi.NotFoundException;

import aiss.model.Video;
import aiss.model.repository.MapMovidedatabaissRepository;
import aiss.model.repository.MoviedatabaissRepository;

@Path("/videos")
public class VideosApiResource {

	public static VideosApiResource _instance = null;
	MoviedatabaissRepository repository;

	private VideosApiResource() {
		repository = MapMovidedatabaissRepository.getInstance();

	}

	public static VideosApiResource getInstance() {
		if (_instance == null)
			_instance = new VideosApiResource();
		return _instance;
	}

	// Método que devuelve todos los vídeos
	@GET
	@Produces("application/json")
	public Collection<Video> getAllVideos() {
		return repository.getAllMovieVideos();
	}
	
	// Método que devuelve el video de la id de una determinado pelicula
	@GET
	@Path("/{idMovie}")
	@Produces("application/json")
	public Video getMovieVideoById(@QueryParam("idMovie") String idMovie) {
		Video res = repository.getMovieVideoById(idMovie);
		if (res == null) {
			throw new NotFoundException("No se encuentra ningún vídeo.");
		}
		return res;
	}
	
	// Método que devuelve todos los vídeos del nombre de una determinada pelicula
	@GET
	@Path("/{titleMovie}")
	@Produces("application/json")
	public Collection<Video> getAllVideosByTitle(@QueryParam("titleMovie") String titleMovie) {
		Collection<Video> res = repository.getMovieVideosByTitle(titleMovie);
		if (res == null) {
			throw new NotFoundException("No se encuentra ningún vídeo.");
		}
		return res;
	}	
	
	// Método que devuelve un vídeo con una determinada id
	@GET
	@Path("/{idVideo}")
	@Produces("application/json")
	public Video getVideoById(@PathParam("idVideo") String idVideo) {
		Video video = repository.getVideoById(idVideo);
		if (video == null) {
			throw new BadRequestException("El vídeo solicitado no existe.");
		}
		return video;
	}
		
	// Método que añade un video
	@POST
	@Consumes("application/json")
	@Produces("application/json")
	public Response addVideo(@Context UriInfo uriInfo, Video video) {
		if (video.getTitle() == null || "".equals(video.getTitle()))
			throw new BadRequestException("The name of the Video must not be null");
		repository.addVideo(video);
		UriBuilder ub = uriInfo.getAbsolutePathBuilder().path(this.getClass(), "get");
		URI uri = ub.build(video.getId());
		ResponseBuilder resp = Response.created(uri);
		resp.entity(video);			
		return resp.build();
	}
	
	// Método que actualiza un video
	@PUT
	@Consumes("application/json")
	public Response updateVideo(Video video) {
		Video oldVideo = repository.getVideoById(video.getId());
		if (oldVideo == null) {
			throw new NotFoundException("The Video with id="+ video.getId() +" was not found");			
		}
		
		// Update name
		if (video.getTitle()!=null) {
			oldVideo.setTitle(video.getTitle());
		}
				
		return Response.noContent().build();
	}
	
	// Método que elimina un video
	@DELETE
	@Path("/{idVideo}")
	public Response removeVideo(@PathParam("idVideo") String idVideo) {
		Video toberemoved=repository.getVideoById(idVideo);
		if (toberemoved == null)
			throw new NotFoundException("The Video with id="+ idVideo +" was not found");
		else
			repository.deleteVideo(idVideo);
		
		return Response.noContent().build();
	}

}