package aiss.controller;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import aiss.model.resource.TMDBResource;
import aiss.model.tmdb.Search;

public class SearchController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private static final Logger log = Logger.getLogger(SearchController.class.getName());

	public SearchController() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd = null;

		// Obtenemos el parámetro de búsqueda de la pelicula
		String query = request.getParameter("searchQuery");
		log.log(Level.FINE, "Searching for TMDB movies that contain " + query);

		//Obtenemos las distintas peliculas
		TMDBResource tmdb = new TMDBResource();
		Search tmdbResults =tmdb.getMovie(query);
		
		// Comprobamos los resultados y en caso no obtenerlos se redirigirá a la página de error
		if (tmdbResults != null) {
			log.log(Level.INFO, "Buscando películas.");
			request.setAttribute("movies", tmdbResults.getMovies());	
			rd = request.getRequestDispatcher("/resultsView.jsp");
			log.log(Level.FINE, "Búsqueda de película realizada y procesada correctamente.");
		} else {
			log.log(Level.SEVERE, "OMDb object: " + tmdbResults);
			rd = request.getRequestDispatcher("/error.jsp");
		}
		
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)	throws ServletException, IOException {
		doGet(request, response);
	}
}