package aiss.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import aiss.model.resource.TMDBResource;
import aiss.model.resource.YoutubeResource;
import aiss.model.tmdb.Review;
import aiss.model.tmdb.Reviews;
import aiss.model.tmdb.Search;
import aiss.model.youtube.SearchVideos;

public class SelectedMovieController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private static final Logger log = Logger.getLogger(SelectedMovieController.class.getName());

	public SelectedMovieController() {
		super();
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd = null;

		log.log(Level.INFO, "Procesando SelectedMovieController.");
				
		// Obtenemos el parámetro de búsqueda de la pelicula
		String query = request.getParameter("searchQuery");
		

		
		// Obtenemos los resultados de TMDB según la búsqueda realizada
		log.log(Level.INFO, "Buscando para TMDB información de " + query);
		TMDBResource tmdb = new TMDBResource();
		Search tmdbResults = tmdb.getMovie(query);
		
		// Creamos el recurso de YouTube
//		YoutubeResource yt = new YoutubeResource();
//		log.log(Level.INFO, "Buscando para YouTube vídeos de " + query);
//		SearchVideos ytResults = yt.getTrailer(tmdbResults.getMovies().get(0).getTitle() + " trailer");
		
		//Creamos recurso con la reseña de la pelicula
		log.log(Level.INFO, "Buscando Review de " + query);
		Reviews Reviews= tmdb.getReviews(tmdbResults.getMovies().get(0).getId());
		
		
		// Comprobamos los resultados y en caso no obtenerlos se redirigirá a la página de error
		if (tmdbResults != null /*&& ytResults != null*/) {
			request.setAttribute("movie", tmdbResults.getMovies().get(0));
//			request.setAttribute("videos", ytResults);
			if (!Reviews.getReviews().isEmpty()) {
				request.setAttribute("review", Reviews.getReviews().get(0));
			}
			request.setAttribute("reviews_size", Reviews.getReviews().size());
			
			rd = request.getRequestDispatcher("/selectedMovie.jsp");
			log.log(Level.FINE, "Búsqueda de información y vídeos realizada y procesada correctamente.");
		} else {
			log.log(Level.WARNING, "Error al realizar la búsqueda");
			rd = request.getRequestDispatcher("/error.jsp");
		}
		
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)	throws ServletException, IOException {
		doGet(request, response);
	}
}