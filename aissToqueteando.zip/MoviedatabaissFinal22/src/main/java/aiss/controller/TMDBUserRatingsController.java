package aiss.controller;

import java.io.IOException;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import aiss.model.resource.TMDBResource;
import aiss.model.tmdb.Token;

public class TMDBUserRatingsController extends HttpServlet{
	private static final Logger log = Logger.getLogger(TMDBUserRatingsController.class.getName());

    @Override
    public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {

//        String accessToken = (String) req.getSession().getAttribute("TMDB-token");
//
//        if (accessToken != null && !"".equals(accessToken)) {
    		
        	TMDBResource TMDBRes = new TMDBResource();//accessToken
        	Token token = TMDBRes.getRequest_token();
        	String request_token = token.getRequest_token();
        	log.info("AAAAAQUUUUIII"+request_token);
        	req.setAttribute("token",request_token);
        	req.getRequestDispatcher("auxiliar.jsp").forward(req, resp);
        	/*String session_id= TMDBRes.getSessionId(request_token);
        	List<Rated> ratings = TMDBRes.getRatedMoviesUser(session_id);

            if (ratings != null) {
                req.setAttribute("rated", ratings);
                req.getRequestDispatcher("/TMDBUserRatings.jsp").forward(req, resp);
            } else {
                log.info("The ratings returned are null... probably your token has experied. Redirecting to OAuth servlet.");
                req.getRequestDispatcher("/AuthController/TMBD").forward(req, resp);
            }
//        } else {
//            log.info("Trying to access TMBD without an access token, redirecting to OAuth servlet");
//            req.getRequestDispatcher("/AuthController/TMBD").forward(req, resp);
//        }*/
    }

    @Override
    public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
        doGet(req, resp);
    }
    
}
