package aiss.model;

import java.util.ArrayList;
import java.util.List;

public class Pelicula {
	private String id;
	private String name;
	private List<Genero> genre;
	private String releaseDate;
	private String overview;
	private Double voteAverage;
	private String posterPath;
	private Video video;
	private List<Reseña> reviews;
	/////////////////////// TO DO ADD SCORE ///////////////////////////////

	public Pelicula() {
	}

	public Pelicula(String id, String name, List<Genero> genre, String releaseDate, String overview, Double voteAverage,
			String posterPath, Video video, List<Reseña> reviews) {
		this.id = id;
		this.name = name;
		this.genre = genre;
		this.releaseDate = releaseDate;
		this.overview = overview;
		this.voteAverage = voteAverage;
		this.posterPath = posterPath;
		this.video = video;
		this.reviews = reviews;
	}

	public Pelicula(String name, List<Genero> genre, String releaseDate, String overview, Double voteAverage,
			String posterPath, Video video, List<Reseña> reviews) {
		this.name = name;
		this.genre = genre;
		this.releaseDate = releaseDate;
		this.overview = overview;
		this.voteAverage = voteAverage;
		this.posterPath = posterPath;
		this.video = video;
		this.reviews = reviews;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Genero> getGenre() {
		return genre;
	}

	public void setGenre(List<Genero> genre) {
		this.genre = genre;
	}

	public String getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(String releaseDate) {
		this.releaseDate = releaseDate;
	}

	public String getOverview() {
		return overview;
	}

	public void setOverview(String overview) {
		this.overview = overview;
	}

	public Double getVoteAverage() {
		return voteAverage;
	}

	public void setVoteAverage(Double voteAverage) {
		this.voteAverage = voteAverage;
	}

	public String getPosterPath() {
		return posterPath;
	}

	public void setPosterPath(String posterPath) {
		this.posterPath = posterPath;
	}

	public Video getVideo() {
		return video;
	}

	public void setVideo(Video video) {
		this.video = video;
	}

	public List<Reseña> getReviews() {
		return reviews;
	}

	public Reseña getReview(String idReview) {
		if (reviews == null)
			return null;

		Reseña reseña = null;
		for (Reseña s : reviews)
			if (s.getId().equals(idReview)) {
				reseña = s;
				break;
			}

		return reseña;
	}

	public void addReview(Reseña e) {
		if (reviews == null) {
			reviews = new ArrayList<Reseña>();
		}
		reviews.add(e);
	}

	public void deleteReview(Reseña r) {
		reviews.remove(r);
	}

	public void deleteReview(String idReview) {
		Reseña r = getReview(idReview);
		if (r != null) {
			reviews.remove(r);
		}
	}

	/////////////////////// TO DO ADD SCORE ///////////////////////////////

}