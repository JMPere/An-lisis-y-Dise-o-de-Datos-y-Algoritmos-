package aiss.model;

public class Reseña {
	private String id;
	private String url;
	private String autor;
	private String comentario;
	
	public Reseña() {}

	public Reseña(String id, String url, String autor, String comentario) {
		this.id = id;
		this.url = url;
		this.autor = autor;
		this.comentario = comentario;
	}
	
	public Reseña(String url, String autor, String comentario) {
		this.url = url;
		this.autor = autor;
		this.comentario = comentario;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getAutor() {
		return autor;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}

	public String getComentario() {
		return comentario;
	}

	public void setComentario(String comentario) {
		this.comentario = comentario;
	}

}