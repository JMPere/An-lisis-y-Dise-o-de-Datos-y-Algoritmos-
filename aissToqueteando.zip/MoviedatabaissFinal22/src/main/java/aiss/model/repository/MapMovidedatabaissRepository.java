package aiss.model.repository;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import aiss.model.Genero;
import aiss.model.Pelicula;
import aiss.model.Reseña;
import aiss.model.Video;


public class MapMovidedatabaissRepository implements MoviedatabaissRepository {

	Map<String, Pelicula> movieMap;
	Map<String, Video> videoMap;
	Map<String, Reseña> reviewMap;
	private static MapMovidedatabaissRepository instance = null;
	private int index = 0;

	public static MapMovidedatabaissRepository getInstance() {

		if (instance == null) {
			instance = new MapMovidedatabaissRepository();
			instance.init();
		}

		return instance;
	}

	public void init() {

		movieMap = new HashMap<String, Pelicula>();
		videoMap = new HashMap<String, Video>();
		reviewMap = new HashMap<String, Reseña>();

		// Create genres

		Genero adventure = new Genero();
		adventure.setName("adventure");
		Genero fantasy = new Genero();
		fantasy.setName("adventure");
		Genero terror = new Genero();
		terror.setName("adventure");
		Genero comedy = new Genero();
		comedy.setName("adventure");

		// Create videos
		Video shrekVideo = new Video("Trailer Shrek", "https://youtu.be/vZ734NWnAHA");
		addVideo(shrekVideo);
		Video starWarsVideo = new Video("Trailer Star wars", "https://youtu.be/vZ734NWnAHA");
		addVideo(starWarsVideo);
		
		//Create Review
		Reseña review1 = new Reseña("gshajkdhlasf", "Spencer Pere", "morta wo");
		Reseña review2 = new Reseña("gshajkfdsdhlasf", "jotaeme Pere", "vamooo");
		Reseña review3 = new Reseña("gshajkdasdasdhlasf", "jomape Pere", "hoy no voy a clase");
		addReview(review1);
		addReview(review2);
		addReview(review3);

		// Create movies

		Pelicula shrekPelicula = new Pelicula();
		shrekPelicula.setName("Shrek");
		shrekPelicula.setOverview(
				"Había una vez, en un pantano muy lejano, vivía un ogro llamado Shrek (Mike Myers) cuya preciosa soledad se ve súbitamente interrumpida por la invasión de los ruidosos personajes de los cuentos de hadas. Todos fueron expulsados de sus reinos por el malvado Lord Farquaad (John Lithgow). Decidido a salvar su casa, Shrek hace un trato con Farquaad y se prepara para rescatar a la princesa Fiona (Cameron Diaz) para que sea la novia de Farquaad.");
		shrekPelicula.setPosterPath("cGjhCcYhTGWxXlDJMWrK2lUa5PZ.jpg");
		List<Genero> generos1 = new ArrayList<Genero>();
		generos1.add(adventure);
		generos1.add(fantasy);
		generos1.add(comedy);
		shrekPelicula.setGenre(generos1);
		shrekPelicula.setReleaseDate("19-04-2002");
		shrekPelicula.setVideo(shrekVideo);
		shrekPelicula.setVoteAverage(7.5);
		shrekPelicula.addReview(review1);
//		addReview(shrekPelicula.getId(), review1.getId());
//		addReview(shrekPelicula.getId(), review2.getId());
		addMovie(shrekPelicula);

		Pelicula starWarsPelicula = new Pelicula();
		starWarsPelicula.setName("Star wars");
		starWarsPelicula.setOverview(
				"Princess Leia is captured and held hostage by the evil Imperial forces in their effort to take over the galactic Empire. Venturesome Luke Skywalker and dashing captain Han Solo team together with the loveable robot duo R2-D2 and C-3PO to rescue the beautiful princess and restore peace and justice in the Empire.");
		starWarsPelicula.setPosterPath("cGjhCcYhTGWxXlDJMWrK2lUa5PZ.jpg");
		List<Genero> generos2 = new ArrayList<Genero>();
		generos2.add(adventure);
		generos2.add(fantasy);
		starWarsPelicula.setGenre(generos2);
		starWarsPelicula.setReleaseDate("19-04-1977");
		starWarsPelicula.setVideo(starWarsVideo);
		starWarsPelicula.setVoteAverage(8.2);
		starWarsPelicula.addReview(review2);
//		addReview(starWarsPelicula.getId(), review3.getId());
		addMovie(starWarsPelicula);

	}

	// Metodos videos
	
	@Override
	public void addVideo(Video s) {
		String id = "s" + index++;
		s.setId(id);
		videoMap.put(id, s);
	}
	
	@Override
	public void updateVideo(Video s) {
		Video song = videoMap.get(s.getId());
		song.setTitle(s.getTitle());
		song.setUrl(s.getUrl());
	}

	@Override
	public void deleteVideo(String songId) {
		videoMap.remove(songId);
	}


	@Override
	public Collection<Video> getAllMovieVideos() {
		return videoMap.values();
	}

	@Override
	public Collection<Video> getMovieVideosByTitle(String title) {
		Collection<Video> res = new HashSet<>();
		for (Pelicula a : getMoviesByTitle(title)) {
			res.add(a.getVideo());
		}
		return res;
	}

	@Override
	public Video getMovieVideoById(String idMovie) {
		return getMovieById(idMovie).getVideo();
	}

	@Override
	public Video getVideoById(String idYoutube) {
		Video res = null;
		for (Video i : getAllMovieVideos()) {
			if (i.getId().equals(idYoutube)) {
				res = i;
				break;
			}
		}
		return res;
	}

	//Metodos Reseñas
	@Override
	public Collection<Reseña> getAllReviews() {
		return reviewMap.values();
	}

	@Override
	public void updateReview(Reseña r) {
		Reseña reseña = reviewMap.get(r.getId());
		reseña.setAutor(r.getAutor());
		reseña.setComentario(r.getComentario());
		reseña.setUrl(r.getUrl());		
	}

	@Override
	public void addReview(Reseña r) {
		String id = "r" + index++;
		r.setId(id);
		reviewMap.put(id, r);
		
	}

	@Override
	public void deleteReview(String idReview) {
		reviewMap.remove(idReview);
		
	}
	
	@Override
	public Collection<Reseña> getReviewsByAutor(String title) {
		Collection<Reseña> reseñas = new HashSet<Reseña>();
		for (Reseña reseña : getAllReviews()) {
			if (reseña.getAutor().equals(title)) {
				reseñas.add(reseña);
			}
		}
		return reseñas;
	}

	@Override
	public Reseña getReviewById(String idReview) {
		Reseña reseñas = new Reseña();
		for (Reseña reseña : getAllReviews()) {
			if (reseña.getId().equals(idReview)) {
				reseñas = reseña;
			}
		}
		return reseñas;
	}


	// Metodos Peliculas

	@Override
	public Collection<Pelicula> getAllMovies() {
		return movieMap.values();
	}

	@Override
	public Pelicula getMovieById(String idMovie) {
		return movieMap.get(idMovie);
	}

	@Override
	public Collection<Pelicula> getMoviesByTitle(String title) {
		Collection<Pelicula> res = new HashSet<Pelicula>();
		for (Pelicula peli : getAllMovies()) {
			if (peli.getName().contentEquals(title)) {
				res.add(peli);
			}
		}
		return res;
	}

	@Override
	public void addMovie(Pelicula p) {
		String id = "m" + index++;
		p.setId(id);
		movieMap.put(id, p);

	}
	
	@Override
	public void updateMovie(Pelicula id) {
		if (getAllMovies().contains(id)) {
			movieMap.put(id.getId(), id);
		}
		
	}

	@Override
	public void deleteMovie(String id) {
		movieMap.remove(id);
		
	}

	@Override
	public void addReview(String idMovie, String idReview) {
		for (Reseña reseña : getAllReviews()) {
			if (reseña.getId().equals(idReview)) {
				getMovieById(idMovie).addReview(reseña);;
			}
		}
	}

	@Override
	public Collection<Reseña> getReviewsByMovie(String idMovie) {
		return getMovieById(idMovie).getReviews();
	}

	@Override
	public void deleteReview(String idMovie, String idReview) {
		for (Pelicula p : getAllMovies()) {
			if (p.getId().equals(idMovie)) {
				for (Reseña r : getReviewsByMovie(p.getId())) {
					if (r.getId().equals(idReview)) {
						p.deleteReview(r);
						break;
					}
				}
			}
		}
		
	}

	

}
