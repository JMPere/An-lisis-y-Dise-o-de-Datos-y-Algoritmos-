package aiss.model.repository;

import java.util.Collection;

import aiss.model.Pelicula;
import aiss.model.Reseña;
import aiss.model.Video;

public interface MoviedatabaissRepository {
	
	//Métodos de Películas
	public Collection<Pelicula> getAllMovies();
	public Pelicula getMovieById(String idMovie);
	public Collection<Pelicula> getMoviesByTitle(String title);
	public void addMovie(Pelicula id);
	public void updateMovie(Pelicula id);
	public void deleteMovie(String id);
	public void addReview(String idMovie, String idReview);
	public void deleteReview(String idMovie, String idReview);

	//public void addScore(String idMovie, Score s);
	
	// Métodos de Video
	public Collection<Video> getAllMovieVideos();
	public Collection<Video> getMovieVideosByTitle(String title);
	public Video getMovieVideoById(String idMovie);
	public Video getVideoById(String idYoutube);
	void deleteVideo(String songId);
	void updateVideo(Video s);
	void addVideo(Video s);
	
	//Metodos Review
	public Collection<Reseña> getAllReviews();
	public Collection<Reseña> getReviewsByAutor(String title);
	public Collection<Reseña> getReviewsByMovie(String title);
	public Reseña getReviewById(String idReview);
	public void updateReview(Reseña r);
	public void addReview(Reseña r);
	public void deleteReview(String idReview);

	
}
