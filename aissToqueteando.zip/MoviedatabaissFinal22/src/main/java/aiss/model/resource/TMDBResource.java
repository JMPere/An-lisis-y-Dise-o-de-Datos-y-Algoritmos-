package aiss.model.resource;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.List;
import java.util.logging.Logger;

import org.restlet.resource.ClientResource;
import org.restlet.resource.ResourceException;

import aiss.model.tmdb.Rated;
import aiss.model.tmdb.RatedMovies;
import aiss.model.tmdb.Reviews;
import aiss.model.tmdb.Search;
import aiss.model.tmdb.Session;
import aiss.model.tmdb.Token;

public class TMDBResource {

	private static final Logger log = Logger.getLogger(TMDBResource.class.getName());
	private final Token request_token;
	private final String baseURL = "https://api.themoviedb.org/3";
	private final String API_KEY = "0ad4c3d1f4630e062a53356088b81e31";

	public Token getRequest_token() {
		return request_token;
	}

	public TMDBResource() {
		// TODO Auto-generated constructor stub
		request_token = getNewRequestToken();
	}

	public Token getNewRequestToken() {
		String tokenGetUrl = baseURL + "/authentication/token/new?api_key=" + API_KEY;

		ClientResource cr = new ClientResource(tokenGetUrl);

		Token token = null;
		try {
			cr.setEntityBuffering(true);
			token = cr.get(Token.class);

			return token;

		} catch (ResourceException re) {
			log.warning("Error when retrieving token: " + cr.getResponse().getStatus());
			log.warning(tokenGetUrl);
			return null;
		}
	}

	public String getSessionId(String request_token) {

		String sessionIdUrl = baseURL + "/authentication/session/new?api_key=" + API_KEY;

		ClientResource cr = new ClientResource(sessionIdUrl);

		Session session = null;
		try {
			cr.setEntityBuffering(true);
			session = cr.post(request_token, Session.class);

			return session.getSession_id();

		} catch (ResourceException re) {
			log.warning("Error when retrieving session: " + cr.getResponse().getStatus());
			log.warning(sessionIdUrl);
			return null;
		}
	}

	public List<Rated> getRatedMoviesUser(String session_id) {

		String ratedMoviesUserUrl = baseURL + "/account/{account_id}/rated/movies?api_key="+API_KEY+"&session_id="+session_id+"sort_by=created_at.asc";

		ClientResource cr = new ClientResource(ratedMoviesUserUrl);

		RatedMovies rateds = null;
		try {
			cr.setEntityBuffering(true);
			rateds = cr.get(RatedMovies.class);

			return rateds.getResults();

		} catch (ResourceException re) {
			log.warning("Error when retrieving rated movies: " + cr.getResponse().getStatus());
			log.warning(ratedMoviesUserUrl);
			return null;
		}
	}

	public Search getMovie(String name) throws UnsupportedEncodingException {
		String title = URLEncoder.encode(name, "UTF-8");
		String movieGetURL = baseURL + "/search/movie/?api_key=" + API_KEY + "&query=" + title;

		ClientResource cr = new ClientResource(movieGetURL);

		Search movies = null;
		try {
			movies = cr.get(Search.class);
			return movies;

		} catch (ResourceException re) {
			log.warning("Error when retrieving movies: " + cr.getResponse().getStatus());
			log.warning(movieGetURL);
			return null;
		}
	}

	public Reviews getReviews(Integer movie_id) {
		// ejemplo avengers endgame:
		// https://api.themoviedb.org/3/movie/299534/reviews?api_key=0ad4c3d1f4630e062a53356088b81e31&language=en-US&page=1
		String language = "en-US";
		String page = "1";
		String movieGetURL = baseURL + "/movie/" + movie_id + "/reviews?api_key=" + API_KEY + "&language=" + language
				+ "&page=" + page;

		ClientResource cr = new ClientResource(movieGetURL);
		Reviews reviews = null;
		try {

			reviews = cr.get(Reviews.class);
			return reviews;

		} catch (ResourceException e) {
			log.warning("Error when retrieving reviews: " + cr.getResponse().getStatus());
			log.warning(movieGetURL);
			return null;
		}

	}

}
