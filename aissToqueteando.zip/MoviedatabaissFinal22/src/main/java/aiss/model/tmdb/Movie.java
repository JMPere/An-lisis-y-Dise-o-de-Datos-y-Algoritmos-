package aiss.model.tmdb;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "genres", "homepage", "id", "original_title", "overview", "release_date", "runtime", "title",
		"video", "vote_average","poster_path"})
@JsonIgnoreProperties(ignoreUnknown = true)
public class Movie {

	@JsonProperty("genres")
	private List<Genre> genres = null;
	@JsonProperty("homepage")
	private Object homepage;
	@JsonProperty("id")
	private Integer id;
	@JsonProperty("original_title")
	private String originalTitle;
	@JsonProperty("overview")
	private String overview;
	@JsonProperty("release_date")
	private String releaseDate;
	@JsonProperty("runtime")
	private Integer runtime;
	@JsonProperty("title")
	private String title;
	@JsonProperty("video")
	private Boolean video;
	@JsonProperty("vote_average")
	private Double voteAverage;
	@JsonProperty("poster_path")
	private String posterPath;

	@JsonProperty("genres")
	public List<Genre> getGenres() {
		return genres;
	}

	@JsonProperty("genres")
	public void setGenres(List<Genre> genres) {
		this.genres = genres;
	}

	@JsonProperty("homepage")
	public Object getHomepage() {
		return homepage;
	}

	@JsonProperty("homepage")
	public void setHomepage(Object homepage) {
		this.homepage = homepage;
	}

	@JsonProperty("id")
	public Integer getId() {
		return id;
	}

	@JsonProperty("id")
	public void setId(Integer id) {
		this.id = id;
	}

	@JsonProperty("original_title")
	public String getOriginalTitle() {
		return originalTitle;
	}

	@JsonProperty("original_title")
	public void setOriginalTitle(String originalTitle) {
		this.originalTitle = originalTitle;
	}

	@JsonProperty("overview")
	public String getOverview() {
		return overview;
	}

	@JsonProperty("overview")
	public void setOverview(String overview) {
		this.overview = overview;
	}

	@JsonProperty("release_date")
	public String getReleaseDate() {
		return releaseDate;
	}

	@JsonProperty("release_date")
	public void setReleaseDate(String releaseDate) {
		this.releaseDate = releaseDate;
	}

	@JsonProperty("runtime")
	public Integer getRuntime() {
		return runtime;
	}

	@JsonProperty("runtime")
	public void setRuntime(Integer runtime) {
		this.runtime = runtime;
	}

	@JsonProperty("title")
	public String getTitle() {
		return title;
	}

	@JsonProperty("title")
	public void setTitle(String title) {
		this.title = title;
	}

	@JsonProperty("video")
	public Boolean getVideo() {
		return video;
	}

	@JsonProperty("video")
	public void setVideo(Boolean video) {
		this.video = video;
	}

	@JsonProperty("vote_average")
	public Double getVoteAverage() {
		return voteAverage;
	}

	@JsonProperty("vote_average")
	public void setVoteAverage(Double voteAverage) {
		this.voteAverage = voteAverage;
	}

	@JsonProperty("poster_path")
	public String getPosterPath() {
		return posterPath;
	}

	@JsonProperty("poster_path")
	public void setPosterPath(String posterPath) {
		this.posterPath = posterPath;
	}
	
	

}
