package aiss.model.tmdb;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "title", "overview", "rating", "vote_average", "vote_count" })
@JsonIgnoreProperties(ignoreUnknown = true)

public class Rated {

	@JsonProperty("title")
	private Integer title;
	
	@JsonProperty("overview")
	private List<Rated> overview;
	
	@JsonProperty("rating")
	private Integer rating;
	
	@JsonProperty("vote_average")
	private Integer vote_average;
	
	@JsonProperty("vote_count")
	private Integer vote_count;

	public Integer getTitle() {
		return title;
	}

	public List<Rated> getOverview() {
		return overview;
	}

	public Integer getRating() {
		return rating;
	}

	public Integer getVote_average() {
		return vote_average;
	}

	public Integer getVote_count() {
		return vote_count;
	}
	
	
	
}
