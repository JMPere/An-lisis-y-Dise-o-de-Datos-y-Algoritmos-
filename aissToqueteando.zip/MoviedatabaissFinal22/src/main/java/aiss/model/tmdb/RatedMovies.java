package aiss.model.tmdb;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "page", "results", "total_pages", "total_results" })
@JsonIgnoreProperties(ignoreUnknown = true)

public class RatedMovies {
	
	@JsonProperty("page")
	private Integer page;
	
	@JsonProperty("results")
	private List<Rated> results;
	
	@JsonProperty("total_pages")
	private Integer total_pages;
	
	@JsonProperty("total_results")
	private Integer total_results;

	public Integer getPage() {
		return page;
	}

	public List<Rated> getResults() {
		return results;
	}

	public Integer getTotal_pages() {
		return total_pages;
	}

	public Integer getTotal_results() {
		return total_results;
	}
	
	
	

}
