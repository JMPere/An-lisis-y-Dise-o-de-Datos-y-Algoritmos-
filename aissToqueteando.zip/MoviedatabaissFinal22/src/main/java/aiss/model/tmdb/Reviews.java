package aiss.model.tmdb;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "total_results", "results" })
@JsonIgnoreProperties(ignoreUnknown = true)

public class Reviews {
	
	@JsonProperty("total_results")
	private Integer total_results;		
	
	@JsonProperty("results")
	private List<Review> reviews;
	

	@JsonProperty("total_results")
	public Integer getTotal_results() {
		return total_results;
	}

	@JsonProperty("results")
	public List<Review> getReviews() {
		return reviews;
	}

	@JsonProperty("total_results")
	public void setTotal_results(Integer total_results) {
		this.total_results = total_results;
	}

	@JsonProperty("results")
	public void setReviews(List<Review> reviews) {
		this.reviews = reviews;
	}
	
	
	
	
	
}
