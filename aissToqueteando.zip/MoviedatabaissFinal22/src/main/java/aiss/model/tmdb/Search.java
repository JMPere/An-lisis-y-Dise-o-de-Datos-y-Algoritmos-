package aiss.model.tmdb;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "total_results", "results" })
@JsonIgnoreProperties(ignoreUnknown = true)

public class Search {

	@JsonProperty("total_results")
	private Integer totalResults;
	@JsonProperty("results")
	private List<Movie> movies = null;
	@JsonProperty("total_results")
	public Integer getTotalResults() {
		return totalResults;
	}

	@JsonProperty("total_results")
	public void setTotalResults(Integer totalResults) {
		this.totalResults = totalResults;
	}

	@JsonProperty("results")
	public List<Movie> getMovies() {
		return movies;
	}

	@JsonProperty("results")
	public void setMovies(List<Movie> movies) {
		this.movies = movies;
	}

}
