package aiss.model.tmdb;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "success", "session_id" })
@JsonIgnoreProperties(ignoreUnknown = true)

public class Session {

	@JsonProperty("success")
	private boolean success;

	@JsonProperty("session_id")
	private String session_id;

	public boolean isSuccess() {
		return success;
	}

	public String getSession_id() {
		return session_id;
	}
}
