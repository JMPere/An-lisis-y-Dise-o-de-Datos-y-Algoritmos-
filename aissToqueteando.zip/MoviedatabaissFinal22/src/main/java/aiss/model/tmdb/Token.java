package aiss.model.tmdb;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "success", "expires_at", "request_token" })
@JsonIgnoreProperties(ignoreUnknown = true)

public class Token {
	
	@JsonProperty("success")
	private boolean success;
	
	@JsonProperty("expires_at")
	private String expires_at;
	
	@JsonProperty("request_token")
	private String request_token;

	public boolean isSuccess() {
		return success;
	}

	public String getExpires_at() {
		return expires_at;
	}

	public String getRequest_token() {
		return request_token;
	}

}
