package aiss.model.resources;

import java.io.UnsupportedEncodingException;

import org.junit.Test;

import aiss.model.resource.TMDBResource;
import aiss.model.tmdb.Movie;
import aiss.model.tmdb.Search;

public class TMDBTest {

	@Test
	public void getMoviesTest() throws UnsupportedEncodingException {
		String title = "Shrek";
		TMDBResource movie = new TMDBResource();
		Search omdbResults = movie.getMovie(title);
		
		for (Movie m : omdbResults.getMovies()) {
			
			System.out.println(m.getOriginalTitle());
			
			
		}
		
			
	}

}
