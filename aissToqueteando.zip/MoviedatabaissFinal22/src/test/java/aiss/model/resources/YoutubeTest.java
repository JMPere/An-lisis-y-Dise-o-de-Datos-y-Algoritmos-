package aiss.model.resources;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

import java.io.UnsupportedEncodingException;

import org.junit.Test;

import aiss.model.resource.YoutubeResource;
import aiss.model.youtube.SearchVideos;

public class YoutubeTest {
	@Test
	public void getTrailerTest() throws UnsupportedEncodingException {
		String title = "dogs";		
		YoutubeResource trailer = new YoutubeResource();
		SearchVideos result = trailer.getTrailer(title);
		
		assertNotNull("The search returned null", result.getItems());
		assertNotNull("The search returned null", result.getItems());
		assertFalse("The number of videos for " + title + " is zero", result.getItems()==null);

		System.out.println("The search for " + title + "'s trailer returned " + result.getItems().get(0) + " as id.");
		
	}

}
