package Estructuras;

public class Arbol {
	
	public static Nodo raiz;
	
	public Arbol() {
		// TODO Auto-generated constructor stub
		raiz=null;
	}
	
}
