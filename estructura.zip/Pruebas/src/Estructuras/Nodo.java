package Estructuras;


public class Nodo {
	
	public Nodo padre;
	public Nodo derecha;
	public Nodo izquierda;
	public int llave;
	public Object contenido;
	
	public Nodo(int i) {
		// TODO Auto-generated constructor stub
		padre=null;
		derecha=null;
		izquierda=null;
		llave=i;
		contenido=null;
	}
	
}
