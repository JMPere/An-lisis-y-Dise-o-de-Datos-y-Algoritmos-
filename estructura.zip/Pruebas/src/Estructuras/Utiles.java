package Estructuras;



public class Utiles{
	
	void insertar(int i, Object o) {
		Nodo n = new Nodo(i);
		if(Arbol.raiz==null) {
			n=Arbol.raiz;
		}else {
			
		}
	}
	
}
