package Ej2;

import java.util.Arrays;
import java.util.List;

import us.lsi.bt.EstadoBT;

public class Ej2_BT implements EstadoBT<List<Integer>, Integer, Ej2_BT>{

	private static List<Integer> lista;
	private static Integer n;
	
	private Integer index;
	private Integer res;
	
	
	public static Ej2_BT create() {
		return new Ej2_BT();
	}
	
	public Ej2_BT() {
		lista=SubconjuntoBT.getLista();
		n=SubconjuntoBT.getN();
		index=0;
		res=0;
	}
	
	@Override
	public Tipo getTipo() {
		// TODO Auto-generated method stub
		return Tipo.Max;
	}
	@Override
	public Ej2_BT getEstadoInicial() {
		// TODO Auto-generated method stub
		return Ej2_BT.create();
	}
	@Override
	public Ej2_BT avanza(Integer a) {
		// TODO Auto-generated method stub
		res=+lista.get(a);
		index=a;
		return this;
	}
	@Override
	public Ej2_BT retrocede(Integer a) {
		// TODO Auto-generated method stub
		res=-lista.get(a);
		index=a;
		return this;
	}
	@Override
	public int size() {
		// TODO Auto-generated method stub
		return lista.size()-index;
	}
	@Override
	public boolean esCasoBase() {
		// TODO Auto-generated method stub
		return index==lista.size();
	}
	@Override
	public List<Integer> getAlternativas() {
		// TODO Auto-generated method stub
		return Arrays.asList(0,1);
	}
	@Override
	public List<Integer> getSolucion() {
		// TODO Auto-generated method stub
		
		return null;
	}
	
	@Override
	public Double getObjetivo() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
