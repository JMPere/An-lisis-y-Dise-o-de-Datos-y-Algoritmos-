package Ej2;

import java.util.List;

public class SubconjuntoBT {

	private static List<Integer> lista;
	private static Integer n;

	public static Integer getN() {
		return n;
	}

	public static void setN(Integer n) {
		SubconjuntoBT.n = n;
	}

	public static List<Integer> getLista() {
		return lista;
	}

	public static void setLista(List<Integer> lista) {
		SubconjuntoBT.lista = lista;
	}
	
	
	
}
