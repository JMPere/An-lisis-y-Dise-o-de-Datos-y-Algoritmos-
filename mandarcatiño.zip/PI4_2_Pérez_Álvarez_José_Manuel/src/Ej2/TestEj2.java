package Ej2;

import java.util.LinkedList;
import java.util.List;

import us.lsi.pd.AlgoritmoPD;


public class TestEj2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> p = new LinkedList<>();
		p.add(1);
		p.add(3);
		p.add(1);
		p.add(1);
		p.add(2);
		p.add(5);
		p.add(8);
		p.add(10);
		p.add(6);
		p.add(11);
		Ej2_PDR b = Ej2_PDR.create(0, 0, p,24);
		var a = AlgoritmoPD.createPDR(b);
		a.ejecuta();		
		System.out.println(a.getSolucion());
		
	}

}
