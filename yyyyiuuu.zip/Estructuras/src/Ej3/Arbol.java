package Ej3;

public class Arbol{
	 
    public Nodo raiz;
    public Boolean ordenado;
    
    public Arbol() {
        raiz = null;
        ordenado=null;
    }
    
    public class Nodo {

        public Integer llave;
        public Nodo padre;
        public Nodo izq;
        public Nodo der;
        public Object contenido;
        public Integer altura;

        public Nodo(int llave) {
            this.llave = llave;
            padre=null;
            izq=null;
            der=null;
            contenido=null;
            altura=null;
        }
    }
    
   public void insertarNodo(int v, Object contenido) {
    	
    	Nodo n = new Nodo(v);
    	Integer altura=0;
    	n.contenido=contenido;
    	if(raiz==null) {
    		raiz=n;
    		n.altura=altura;
    	}else {
    		
    		Nodo aux = raiz;
    		
    		while(aux!=null) {
    			
    			n.padre = aux;
    			if(n.llave>=aux.llave) {
    				aux=aux.der;
    			}else {
    				aux=aux.izq;
    			}
    			altura++;
    		}
    		n.altura=altura;
    		if(n.llave<n.padre.llave) {
    			n.padre.izq=n;
    		}else {
    			n.padre.der=n;
    		}
    	}
    }
   
   public void recorridoCompleto(Nodo d) {
   	
	   if(d!=null) {
   			recorridoCompleto(d.izq);
   			System.out.println("Llave: "+d.llave+", contenido: "+d.contenido+", altura: "+d.altura);
   			recorridoCompleto(d.der);
   		}
   }
   
   
    public void arbolOrdenado(Nodo x) {  //----EJ3...
   
    	if(x==this.raiz || this.raiz==null) {
    		ordenado=true;
    	}
    	
    	if(x!=null) {

    		if(x.izq!=null) {
    				if(x.izq.llave>this.raiz.llave && x.izq.llave>x.llave && ordenado==true) {
    				ordenado=false;
    			}
    		}
    		if (x.der!=null) {
				if (x.der.llave<this.raiz.llave && x.der.llave<x.llave && ordenado==true) {
					ordenado=false;
				}
			}
    		arbolOrdenado(x.izq);
    		arbolOrdenado(x.der);
   
    		
    		
    	}
    }
    
    public Boolean getOrdenado() {
 	   arbolOrdenado(this.raiz);
 	return ordenado;
    }								// ...EJ3-----
    
    
}
