package Ej3;

public class Test {
	
	public static void main(String[] args) {
		Arbol arbol = new Arbol();
		
		
		arbol.insertarNodo(4, "Melon");
		arbol.insertarNodo(1, "Platano");
		arbol.insertarNodo(2, "Naranja");
		arbol.insertarNodo(1, "Pera");
		arbol.insertarNodo(7, "Manzana");
		arbol.insertarNodo(5, "Uva");
		arbol.insertarNodo(3, "Sandia");
		
		arbol.recorridoCompleto(arbol.raiz);
		
		System.out.println("\nEl arbol est� ordenado: "+arbol.getOrdenado());
	}
    
}
