package Ej4;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Test {
	
	public static void main(String[] args) {
		List<String> lista =new ArrayList<>();
		
		lista.add("Antonio");
		lista.add("Maria");
		lista.add("Abel");
		lista.add("Sebastian");
		lista.add("Carlos");
		lista.add("Pedro");
		lista.add("Francisco");
		lista.add("Lauro");
		lista.add("Bruno");
		lista.add("Miguel");
		lista.add("Belen");
		lista.add("Jose");
		lista.add("Damian");
		lista.add("Guillermo");
		lista.add("Ruben");
		Collections.sort(lista, Comparator.naturalOrder());
		
		System.out.println(lista+"\n");
		String nombre="Ruben";
		System.out.println("\nPosicion de "+nombre+": "+Util.buscaPosicion(lista, nombre, 0, lista.size()-1));
		
		

	}
	
}
