package Ej4;

import java.util.List;

public class Util{
	
	public static Integer buscaPosicion(List<String> lista, String p, Integer a,Integer b) {
		
		Integer r= ((2 * a) + b) / 3;
		Integer l=(a + (2 * b)) / 3;
		
		System.out.println("a: "+a+" b:"+b+ " pos1:"+r+" pos2:"+l);
		
		if(lista.get(r).compareTo(p)==0 ) {
			return r;
		}
		if(lista.get(l).compareTo(p)==0) {
			return l;
		}
		if(!lista.contains(p)) {
			return -1;
		}
		
		if(p.compareTo(lista.get(r))<0) {
			return buscaPosicion(lista, p, a, r);
		}else {
			if(p.compareTo(lista.get(l))>0) {
				return buscaPosicion(lista, p, r, b);
			}else {
				return buscaPosicion(lista, p, r, l);
			}
		}
		
	}
	
}
